[Part 1](https://my.supernotes.app/?preview=aaa07cdd-92a8-4314-be1a-07824cff2b99)
### Part 1 必考题  
1. Work or studies  
2. Home/accommodation  
3. Hometown  
4. The area you live in  
5. The city you live in  

### Part 1 保留题  
1. Taking photos  
2. APP  
3. Young people/teenagers  
4. Party  
5. Hobby  
6. Fishing  
7. Teachers  
8. Staying at home  
9. Social media  
10. Music/Musical instruments  
11. Gifts  
12. T-shirt  
13. Weekends  
14. Electronic devices/Technology  
15. Books and reading habits  
16. Doing sports  
17. Computers/tablets  
18. Mobile phone  
19. Morning routines  

### Part 1 新题  
1. Happy things  
2. Holidays  
3. Library  
4. Internet  
5. Praise/encouragement  
6. Small business  
7. Chocolate  
8. Singing  
9. Outer space and stars  
10. List  
11. Housework and cooking  
12. Spare time  
13. Spending time by yourself  
14. Writing  
15. Weather  
16. Snacks  
17. Patience  
18. Machine  
19. Memory  
20. Being busy  
21. Puzzles  
22. Saying "thank you"  
23. Public transportation  
24. Staying up  
25. Names  
26. Jewelry  
27. Geography  
28. Birthday  
29. Flowers  
30. Plan/schedule  
31. Text messages  

### Part 2 保留题  
1. Describe a kind of foreign food you like and you have had  
2. Describe one of your grandparents' job  
3. Describe a person who helps to protect the environment  
4. Describe someone else's room you enjoy spending time in  
5. Describe an ideal and perfect place where you would like to stay (e.g. a house, an apartment)  
6. Describe an important decision that you made  
7. Describe a time when you missed or were late for an important meeting/event  
8. Describe a quiet place you like to go  
9. Describe an interesting discussion you had with your friend  
10. Describe someone you like to spend time with  
11. Describe an energetic person that you know  
12. Describe a time you made a promise to someone  

Part 2
### Part 2 新题  
1. Describe the home of someone you know well and that you often visit  
2. Describe something that you did with someone/a group of people  
3. Describe a time when you were praised for something you did  
4. Describe a singer you like  
5. Describe a place where you saw animals  
6. Describe a time when you needed to search for information  
7. Describe your favorite place in your house where you can relax  
8. Describe an outdoor sport you would like to do  
9. Describe a place in your country or part of your country that you would like to recommend to visitors/travelers  
10. Describe a sports event you would like to watch  
11. Describe a person's house/apartment that you think is very good  
12. Describe your first day at school that you remember  
13. Describe a website that sells second-hand items
14. Describe a sports competition you watched  
15. Describe a program you like to watch  
16. Describe a problem you had while shopping online or in a store  
17. Describe a popular place for sports (e.g. a stadium) that you've been to  
18. Describe a time when you saw a lot of plastic waste (e.g. in a park, on the beach, etc.)  
19. Describe a city that you have been to and would like to visit again  
20. Describe a website you often visit  
21. Describe a person you have met who you want to work/study with  
22. Describe a film that made you laugh  
23. Describe a story or novel you have read that you found interesting  
24. Describe a difficult thing you did and succeeded  
25. Describe a person who you think wears unusual clothes  
26. Describe a time when you forgot/missed an appointment  
27. Describe a person from a different cultural background with whom you enjoy spending time  
28. Describe an argument two of your friends had  
29. Describe a time you made a decision to wait for something  
30. Describe a shop/store you often visit  
31. Describe a goal you set that you tried your best to achieve  
32. Describe something you had to share with others  
33. Describe an advertisement which introduced a product you have seen  
34. Describe a friend from your childhood  
35. Describe an impressive English lesson you had and enjoyed  
36. Describe an impressive talk you had  
37. Describe a beautiful sky you enjoyed seeing  
38. Describe a time when you made a plan to do an activity with a lot of people  
39. Describe a person who inspired you to do something interesting  
40. Describe a time when you saw children behave badly in public  
41. Describe a photo you took that you are proud of  
42. Describe a person who persuaded you to do something  
43. Describe a disagreement you had with someone  
44. Describe a movie you watched recently and would like to watch again  
45. Describe a person you disliked at first but ended up being friends with  
46. Describe an object that you think is beautiful  
47. Describe a skill that you think you can teach other people  
48. Describe a friend of yours who is well dressed and is good at dressing up  
49. Describe a noisy place you have been to  
50. Describe an important thing you learned (not at school or college)  
51. Describe a time when you received money as a gift  
52. Describe an intelligent person you know  
53. Describe a person you know who loves to grow plants (e.g. vegetables/fruits/flowers etc.)  
54. Describe an article on health you read in a magazine or on the Internet  
55. Describe a time when someone gave you something that you really wanted  
56. Describe a place you visited and enjoyed in the countryside  
57. Describe a photo that you enjoy looking at  
58. Describe an interesting decision that you and your friend made together  
59. Describe a person who shows his/her feelings very openly  
60. Describe an unusual but interesting building you would like to visit  
61. Describe a famous person you would like to meet

Part 3