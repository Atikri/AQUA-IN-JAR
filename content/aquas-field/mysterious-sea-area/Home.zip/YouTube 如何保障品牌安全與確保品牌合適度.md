- 「移除」違反 YouTube 政策的內容
- 「遏止」有害不實資訊和違規邊緣內容
- 「優先顯示」具公信力的新聞與資訊來源
- 「獎勵」值得信賴的創作者，讓他們能透過自己的內容營利
---
## 追蹤 YouTube 的進展
[YouTube 運作方式](https://www.youtube.com/howyoutubeworks/)說明 Google 採取哪些行動來為 YouTube 社群打造一個負責任的平台。歡迎前往這個網站進一步瞭解以下資訊：
- [控管有害內容](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/our-commitments/managing-harmful-content/)
- [控管不實資訊](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/our-commitments/fighting-misinformation/)
- [YouTube 的規定與政策](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/policies/overview/)
- [YouTube 的營利政策](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/policies/monetization-policies/
- [隱私權控制項](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/user-settings/privacy/)[](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/user-settings/privacy/)
- [家長監護](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/user-settings/parental-controls/)[](https://www.youtube.com/intl/ALL_uk/howyoutubeworks/user-settings/parental-controls/)
此外，你也可以看看一些[創意企業家](https://www.youtube.com/howyoutubeworks/progress-impact/impact/)的故事，瞭解 YouTube 能帶來什麼樣的影響。
---
廣告客戶可透過品牌合適度控管工具微調廣告活動。雖然我們的控管工具無法提升安全，但適合用於確保廣告活動符合品牌識別與價值。
## 廣告空間模式
廣告空間模式是最新的品牌合適度設定，這項必要設定共有三種模式可供品牌選擇：**限制較少的廣告空間、標準廣告空間或受限的廣告空間**。各項設定對不雅用語有不同程度的標準，而可用的廣告空間也會隨之增減。
這項設定推出後，標準廣告空間的適用標準也跟著變高。無論在哪一種模式下，系統都會移除任何駭人聽聞、具煽動性、涉及恐怖主義和暴力衝突的內容。
## 數位內容標籤
數位內容標籤以 G、PG 和 T 等分級為影片分類。這項工具的排除範圍最廣，可讓廣告客戶透過合適的內容放送廣告活動。
YouTube 在判斷應套用哪一種內容標籤時會參考各式各樣的信號，包括影音內容、相關文字或圖片，以及中繼資料。
## 主題控制項
除了指定特定主題的影片外，廣告客戶也能以類似的方式排除特定的內容主題，例如政治或宗教。採取這個步驟，廣告客戶就能排除主題與品牌無關或不符品牌形象的影片，避免自家廣告在這類內容中放送。
我們提供 60 多種類別和 1,500 種子類別讓廣告客戶加入或排除。
## 關鍵字與刊登位置控制項
關鍵字控制項可讓廣告客戶以最精細的方式控制廣告出現的地方。如果廣告客戶為廣告活動加入排除關鍵字，只要影片的標題或說明含有任何一個排除關鍵字，他們的廣告就不會出現在該影片的附近。
## 內容類型控制項
內容類型控制項可讓廣告客戶排除直播內容、內嵌影片及遊戲實況影片中的刊登位置。
這些控制項可讓廣告客戶進一步管理要讓廣告出現在 YouTube 和 Google 多媒體廣告聯播網中的什麼位置，例如，在新聞網站上有關特定事件的內嵌影片開始播放前放送廣告，或是透過創作者在 YouTube 頻道上進行的直播放送廣告。
廣告客戶還可以控制刊登位置 (網站、頻道、影片)，讓特定廣告活動或廣告群組中的廣告不會出現在某些位置上。此外，他們也可以在帳戶層級設定刊登位置控制項，這表示他們指定的控制項會套用到所有 YouTube 和多媒體廣告活動。

 