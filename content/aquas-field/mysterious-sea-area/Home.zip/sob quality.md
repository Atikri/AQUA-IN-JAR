![image.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/f82631c1-96f4-4def-a04d-b4946e005044--image.png)
---
![image.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/0ed2e222-27a2-4b6f-a2e6-0eba666f924f--image.png)
比较低频，比较清晰