IELTS speaking exam can be a stressful experience. Speaking in English to a person who is judging your every word can feel a little scary, to say the least. Put aside your mixed feelings, let hot potatoes be, and let sleeping dogs lie!

That’s why we advise you to use as many **idioms** and **collocations** as you can. This will make your English language sound a lot more natural and fluent. Practice speaking as often as you can, preferably with native speakers. Using idiomatic language naturally will separate native English speakers from intermediate English language learners.

Although **idioms** and **collocations** are both very much alike, there is a difference between the two:

***Collocations*** *can still hold the same meaning when the words are separated.* ***Idioms*** *lose their meaning if the words are split.*

Although there are no specific IELTS idioms, take a look at some frequently used idioms for IELTS here:

## What is an idiom?

An **idiom** is a group of words that creates a specific meaning about a subject. If that group is separated, the meaning is lost. Mastering idiomatic vocabulary will greatly enhance your academic written English and thus increase your IELTS band score. All of them are an excellent tool in your IELTS preparation.

In this podcast tutorial we cover 16 different **idioms**. Some of them are good for describing people – a usual task in the IELTS Speaking Exam. Others are useful for describing interests and activities. The silver lining for using idioms is that you are likely to impress the examiner and therefore increase your chances for a high band score.

## Practising idioms for IELTS speaking exam

To practise learning **idioms** you can try doing this mock IELTS speaking exam. You can time your answers and get a rough idea on how much time you get to answer a question and to what extent you incorporate idiomatic language. Use a drawing board to write down common idioms and create a list for the IELTS writing test in this way.

If you would like more useful information to help you with your IELTS Speaking Exam, you can check out more speaking tips and mock IELTS speaking exams with band 9 answers and samples of spoken English. On the British Council website you’ll find useful samples as well.

## Phrases to help you through your IELTS speaking exam

Use these with caution and only when appropriate. Although they are extremely useful, overuse could sound unnatural, scripted and memorised. Remember that you would like to sound as natural and fluent as native English speakers. Make sure you listen carefully to the question asked and try and go the extra mile.

## If I remember correctly it was…   

This is a great phrase to start talking about something in the past, for example the first time you were eating English food. You could use it quite easily in part 2 of the IELTS speaking section, when giving an example. It’s also suitable for for use with part 3.

## If my memory serves me well… 

This is similar to the phrase above. Phrases like these buy you a few seconds of “thinking time” so you can organise the rest of your answer.

## I can’t remember exactly but I think it was… 

Another variation of the previous two. Using all three of the phrases instead of the same one three times will improve your lexical resource score. The examiner doesn’t want to hear the same news or listen to individual words.

## Well to be totally honest I’ve never really thought about before…  

Another totally natural sounding native English speaker phrase. For band 9 delivery, remember the intonation and rhythm within this phrase. It starts higher, dips in the middle, then picks up at the end, like you would be asking a question.
## I guess you could say…

Similar to the previous one, this is useful when you might not be fully convinced with your own answer. For example, you are asked about a topic you have no idea about.

However, you want to show that you are thinking about this topic and going the extra mile. This is totally fine and natural for an exam conducted under the British Council umbrella. Never forget, IELTS is a test of language, not intelligence. You won’t be losing marks for lack of ideas. It is about the correct use of English.

## It’s funny you should mention that because just yesterday… 

Use this when you want to convey (or make up) something coincendicial. Here the word “funny” is not connected to humour but more like odd or strange. Maybe a new discount store opened in your area or you have just moved to a new city? Listen attentively to the test question.

It’s best to use this if there has been an actual coincidence or you can confidently “manufacture” one.

## Well, I think nowadays it’s a difficult question because… 

This will most likely be useful for part 3, when you start getting more challenging questions and perhaps need a few seconds to prepare.

You would probably never use this in part 1.

## Yes definitely, there are a few reasons for this, firstly….   and secondly… 

Use this to agree with the examiner and, although you’re on the same page, you should build out your answer. Be careful if you receive a question with options like this:

Do you think trust is declining or increasing in modern society?

You must choose one side and then adapt it into your answer but remember: there is no such thing as a perfect answer.

***Trust is definitely decreasing****, there are a few reasons for this, firstly…. and secondly… I will develop this with my best friend as an example. I used to be extremely pleased with his behaviour but over the years …….*

## A list of idioms to help your IELTS speaking exam

### **1. Fresh as a daisy**

Someone who is lively and attractive, in a clean, fresh way.

*My sister has been travelling for almost 24 hours, and she’s still as **fresh as a daisy**.*  

### 2. Couch potato

Spending too much time on the internet or watching TV.

*My uncle is such a **couch potato**! He often spends his Saturdays watching American football on TV.*  

### **3. Full of beans**   

A person who is lively, active and healthy.

*My 6 year old nephew is full of beans! He has more energy than three adults.*

### **4. A bad egg**

Someone who is untrustworthy.

*Hey, Sue, I think your neighbour is a **bad egg**. He has these scary looking guys in black leather hanging around his place all the time.*

### **5. Down to earth**
Someone who is practical and realistic.

*My aunt Karen is so **down to earth**. She can figure out any difficult situation, and offer a good solution.*

### 6. Party pooper

A person who is gloomy, and having no fun at a social gathering.

*Listen, my friend, I’m so sorry to be a **party pooper**, but I have to study for my IELTS speaking exam tomorrow.*

### **7. Eager beaver**

A person who is hardworking and enthusiastic.

*My colleague drives me crazy! **She is such an eager beaver** that she always volunteers for overtime.*

### **8. Ball in your court**

It’s your decision or responsibility to do something now.

*Well, my friend, the **ball’s in your court**. I’ll wait for your decision.*

### **9. Throw in the towel**

Give up.

*I’ve spent too much time on this project to **throw in the towel** now.*

### **10. Get a head start**

Start before all others.

*Let’s get up early tomorrow to **get a head start** on our drive to Toronto.*

### **11. Get a second wind**

Have a burst of energy after tiring.

*After having a coffee and a sandwich, he got **his second wind**, and finished painting the kitchen.*

### **12. Jump the gun**

Start too early.

*I think **I jumped the gun** by buying my friends James and Susan a wedding gift. They just called off their engagement.*

### **13. Give it my best shot**

Try your hardest.

*This test question is really tough! I’ll **give it my best shot**, and I’ll get some marks for doing my best.*

### **14. On the ball**

Ready and able.

*Our department receptionist is really **on the ball** when it comes to fielding calls from annoyed students.*

### **15. Put all your eggs in one basket**  

Put all your effort into one thing or project.  
*In a business context it is usually not wise to* ***put all your eggs in one basket.*** *Try and diversify all your money and get several specialist people involved.*

### **16. In somebody’s shoes**  

In somebody’s (often bad) situation.

*It may sound harsh but I wouldn’t want to be* ***in his shoes*** *with his lack of great business ideas.*