In English, "for good" can indeed mean forever or permanently. It implies that something is done with no intention of reversing it.
Here are a few sentences using "for good" in this sense:
 * After years of struggling, she decided to leave her old job for good and start her own business.
 * The old factory closed down for good last month, leaving many people without jobs.
 * He finally quit smoking for good after his doctor warned him about the health risks.
 * I've decided to move to New Zealand for good; I love it there too much to ever leave.
