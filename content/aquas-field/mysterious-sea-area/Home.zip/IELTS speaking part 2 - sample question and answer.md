## IELTS speaking part 2 - sample question and answer

### **Tell me about your best friend**

**To answer this question in full,**

- **discuss who the person is,**

- **the circumstances of your meeting,**

- **and what it is that you like about them.**

  
!!*Answer: My best friend and I got to know each other when we were still very young. We lived in neighbouring houses. We had **a lot in common**, so we soon **hit it off**.*!!

!!*As we have grown older, we have moved apart. Because of this, we have to some degree **lost touch**, but anyone who has had a **lifelong friend** would understand that she will always be dear to my heart.*!!

!!*When we do find ourselves in the same city, we **arrange a dinner date**, so that we can **enjoy each other’s company**. We **share the same ideas**, and **we share a common background**.*!!

!!*We enjoy reminiscing about our past exploits. When we **struck up a friendship**, as children, we were inseparable. In those early days, we built up **a relationship of trust** that time and distance cannot break.*!!