> Anything's possible P140
> SERVES: 3-4
---
## Ingredients:
 * 1/2 medium cauliflower with leaves (750g), roughly chopped
 * 1 medium beetroot (150g), small cubes
 * 1 green apple (150g), small cubes
 * 1 cup parsley (50g), finely chopped
 * 2 tbsp apple cider vinegar
 * 2 tbsp olive oil
 * 1 tsp sumac
 * 1 tsp salt
 * 1 tsp pepper

---

## Introduction:
As you may already know, we are big fans of challenging the norm when it comes to food waste and what part of the vegetable we do and do not eat.
So what about the cauliflower leaves? Well, this dish adds them in not only for flavour but also as they are a rich source of calcium and iron.
This recipe was inspired by a dear friend of ours and beautiful housemate Kobi. Thanks, Kobi, you're the best.

---


## Instructions:
1. Using a food processor, chop the cauliflower with the leaves until it becomes a rice. Be careful, you don't want it to be too fine like flour.
2. In a large mixing bowl, add the cauliflower rice, beetroot, apple, parsley, apple cider vinegar, olive oil, sumac, salt and pepper. Combine well. It is best served cold.
