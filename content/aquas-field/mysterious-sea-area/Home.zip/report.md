The researchers ==concede== that an individual's own level of education is clearly important for their health,
研究人员==承认==，个人的教育水平对其健康显然很重要，
but they ==assert== that individuals also can ==reap the benefits== of their partner's education.
但他们==断言==，个人也可以从伴侣的教育中获益。
（reap the benefits：这是一个常见的搭配，意思是“获得好处，享受利益”。）
> reap  英 /riːp/
    vt. & vi. 收割庄稼；收获
    (因自己或他人所为)获得(某事物)

Women in this sample had lower levels of education and lower ==occupational achievements== than the men.
在这个样本中，女性的教育水平和==职业成就==都低于男性。

Climate scientists predict that many parts of the world will be increasingly ==prone== to floods.
气候科学家预测，世界上的许多地区将越来越容易发生洪水。
be prone to: 这是一个常见的搭配，表示“易于...的，有...倾向的”。"prone to" 后面通常接名词或动名词，表示容易受到某种事物的影响或容易发生某种情况。
