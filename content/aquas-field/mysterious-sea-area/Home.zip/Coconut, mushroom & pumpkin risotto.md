> Anything's possible :page_with_curl: P196
---
## Ingredients:
- 1/4 kent pumpkin (700g), 2cm cubes with skin on
- 1 cup leek(100g), diced
- 2tsp garlic, minced
- 3tbsp [curry spice mix](https://my.supernotes.app/?preview=f52696c9-fe49-4ec7-baca-87442e96a277) or curry powder of choice
- 1 cup rice
- 3 cups [medicinal vegetable broth](https://my.supernotes.app/?preview=b8c9d722-1a04-4c4b-9cd6-67601810f869) or vegetable stock of choice
- 1 cup mushrooms, either oyster or button, thinly sliced
- 1/2 cup coconut cream
- 1tbsp nutritional yeast
- coconut oil
- salt and pepper
> ## To serve
> 3tbsp parsley(15g), finely chopped
> 1 lemon wedge
> olive oil

---
## Steps:
1. Preheat oven to 200 fan. Line a medium baking tray with baking paper.
2. Add the pumpkin, 1 tablespoon of coconut oil and a generous pinch of salt and pepper to the lined baking tray. Combine well and place in the oven for 40 minutes or until cooked. Remove from the oven and set aside to cool.
3. Put 1 tablespoon of coconut oil into a medium pot and place on a medium-high heat. Once hot, add the leek and sauté for 4-5 minutes, until soft. Add the garlic and [curry spice mix](https://my.supernotes.app/?preview=f52696c9-fe49-4ec7-baca-87442e96a277). Continue to fry, stirring frequently, for a further 2 minutes to release the flavors from the spices. Add the rice and [medicinal vegetable broth](https://my.supernotes.app/?preview=b8c9d722-1a04-4c4b-9cd6-67601810f869). Stir, then put the lid on and reduce to a simmer for 30 minutes or until rice is cooked and resembles porridge.
4. While the rice is cooking, put 1 tablespoon of coconut oil into a medium fry pan and place on a medium-high heat, add mushrooms, sauté for 5 minutes or until cooked. Try not to overcrowd the pan as they will produce too much water. You may have to cook in two lots depending on the size of your fry pan.
5. Once rice is cooked, remove from the heat and stir in the cooked pumpkin, sauté mushrooms, coconut cream, nutritional yeast, 1 teaspoon of salt and 1 teaspoon pepper.

> Serve with parsley, a lemon wedge and a generous drizzle of good quality olive oil.