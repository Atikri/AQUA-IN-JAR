You can take out or add whatever you feel you need. The key ingredients to keep are onion , carrot, celery, garlic, salt and apple cider vinegar. The rest is up to you.

If you know you are going to make stock, we recommend keeping your vegetable peels, onion and garlic skins, hurb stalks etc. in a bag in the freezer. That way when you have a decent amount you can use them to make the stock.

You can add pretty much any vegetable except the following:
- potatoes, sweet potatoes and turnips will make it cloudy.
- beets can overpower your stock.
- zucchini, kale, cabbage, broccoli, bok choy and beans will make it bitter.
---
## Ingredients:
- 1 medium carrot, roughly chopped 
- 1 median onion, roughly chopped with the skin on.
- 2 celery stalks, roughly chopped 
- 6 dried shiitake mushrooms 
- 3 unpeeled garlic cloves, crushed using the back of a knife 
- 1/4 cup parsley stems 
- 1/4 cup coriander stems
- 2 tbsp fresh ginger, grated with skin on
- 2 tbsp apple cider vinegar 
- 4 large bay leaves 
- 4 star anise
- 10 cloves
- 1 tsp fennel seeds
- 1 tsp salt
- 1 tsp pepper 
- 12-15 cups filtered water 

## Equipment 
Nut milk bag or cheese cloth
---
## Steps:
1. Place all of the ingredients into a slow cooker or in a large pot on the stove before adding the water. 
2. Cook on very low heat for 18 to 72 hours, occasionally adding more water if it starts to look low.
3. Once cooked, strain the broth through a nut milk bag or cheese cloth and transfer to a container. You can keep it in the fridge for up to 5 days or alternatively in the freezer for up to three months.