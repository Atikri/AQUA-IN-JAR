Do you like making plans? 
Do you always make plans? 
What do you make plans about?
What are the benefits of making plans?
---
- **Execution** (noun) – the act of carrying out a plan or action. → Maybe not the execution so much, but I like organising everything.
- **Organise** (verb) – to arrange or plan things systematically. → I like organising everything and putting it in place.
- **Account for** (phrasal verb) – to consider or include something when planning. → It makes me feel safe knowing everything has been accounted for.
- **Orderly** (adjective) – arranged or done in a neat, careful, or logical way. → I’m a very orderly person.
- **Productively** (adverb) – in a way that achieves a lot or is efficient. → I plan my day so that it goes as productively as possible.
- **Effectively** (adverb) – in a way that produces the desired result. → I plan my lessons so they’re effective and efficient.
- **Efficient** (adjective) – working well without wasting time or resources. → I plan my lessons so they’re effective and efficient.
- **Finances** (noun) – money and how it is managed. → I like making plans for my finances.
- **Psychological** (adjective) – relating to the mind or mental processes. → There’s the almost psychological security of having everything in order.
- **Stand out** (phrasal verb) – to be noticeable or important. → Those are the two that stand out the most for me.
- **Deadline** (noun) – the latest time or date by which something should be completed. → She set a deadline to finish her project by Friday.
- **Schedule** (noun) – a plan that lists when things will happen. → He keeps a tight schedule during the workweek.
- **Goal** (noun) – something you aim to achieve. → Setting clear goals helps with time management.
- **Contingency** (noun) – a backup plan for unexpected situations. → Every good plan includes a contingency.
- **Prioritise** (verb) – to decide what is most important and deal with that first. → It’s important to prioritise tasks when planning your day.