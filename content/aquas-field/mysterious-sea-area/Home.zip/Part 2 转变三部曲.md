## 混沌之后，重生
![IMG_20250312_134745_edit_736543193665696.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/3a85c23b-cdc1-4f82-9a25-886749873c5a--IMG_20250312_134745_edit_736543193665696.jpg)

仪式三部曲：分离，转变和重整
从原本所熟悉的社会环境中分离出来，经历了一个过渡期，一旦完成内在的转变，将重新回到社会中。