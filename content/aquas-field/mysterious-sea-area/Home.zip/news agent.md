[14 tools called]

已暂停自动生成并清掉最近的每日简报。

- 我做了什么
  - 注释了 `.github/workflows/daily-digest.yml` 的 `schedule`，仅保留手动触发；恢复时把注释去掉即可。
  - 删除了 `content/aquas-field/daily/2025-10-04.md` 到 `2025-10-13.md`。

- 这条 workflow 的底层逻辑
  - 触发: 定时 cron（UTC 01:00）或手动。
  - 运行: `scripts/daily_digest.py`（读取多个源，聚合→生成 Markdown → 写入 `content/aquas-field/daily/日期.md`）。
  - 提交: 若有更新则 `git add` 这些 md 并 push。
  - 依赖: `requirements.txt` 里一般包含 requests/feedparser/markdown/LLM SDK 等；通过 `OPENAI_API_KEY/ANTHROPIC_API_KEY` 走 LLM 摘要与重写。

- 想只抓指定来源（思路）
  - 在 `scripts/daily_digest.py` 里收敛源列表，仅保留你想要的 RSS/API：
    - 纯技术：Hacker News、The Verge、Ars Technica、MIT Tech Review、ETHZ News
    - 学术/原始论文：arXiv RSS（cs.AI、cs.CL、cs.LG）、Nature/Science RSS
    - 中国区资讯：财新/澎湃（如有 RSS 或镜像）、极客公园/少数派（自建抓取或使用其 RSS）
    - 官媒/机构：联合国、新世行、IMF 新闻流
  - 过滤策略：
    - 基于关键词白名单/黑名单（title+summary）
    - 去重（URL hash）
    - 每源限量（如每源最多 3 条）
  - 写入策略：
    - 每日单文件 or 每条单文件；建议“每日单文件”保持目录整洁

- 参考资料（学习“Agent 型新闻助手”）
  - LangChain/LLM Agent 基础
    - LangChain docs “Agents”与“Tool calling”
    - Anthropic “Tool use”/OpenAI “function calling”示例
  - 信息源与聚合
    - “RSS Hub”项目（学会给没有 RSS 的站点加订阅）
    - feedparser（Python）官方文档
  - 质量提升
    - OpenAI “text-davinci/ GPT-4o mini”摘要对比与提示词设计
    - “本地存储 + 语义去重”教程（FAISS/Chroma）

要不要我帮你把 `scripts/daily_digest.py` 改成“仅抓 arXiv cs.AI、HN Top、BBC World 三个源，每日每源最多 3 条，带中文摘要”并加关键词白名单？