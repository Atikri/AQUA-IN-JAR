Do you prefer buying things from big companies or small businesses?
Do you know many small businesses where you live?
Have you ever thought about starting your own business?
Have you ever worked in a small business?
---
run-of-the-mill  - 普通的，一般的
bougie [ˈbuːʒi] - 小资的，追求高品质生活的（俚语，略带贬义）
lend itself to something：固定搭配，“适合于…”，“有助于…”。
it's all panning out："panning out" 是一个固定短语，表示事情进展顺利，结果良好。 "pan out" 原意是淘金时将沙子等杂物淘洗掉，留下金子，引申为事情进展顺利，结果良好。
> Yeah, something develops in a particular way or successful way.So, it panned out well in the end.
> Or I wanted to start my own business, but it didn't pan out.

Not that I can recall: "Not that I can recall" 是一个常见的口语表达，意思是“我不记得了”或“我想不起来”。其中 "that" 在这里可以省略。
counts as the same thing 算作同一件事
No, bourgeois is a word that is French in origin,
but we use it in English all the time to describe this kind of middle class sort of lifestyle.It's to do with the concept of having a lot of luxuries and comforts
Start your own business or set up your own business. And you can say that I've never thought of going into business for myself. So I've never thought of doing something. Go into business,
I think Apple would be not really up my street.
我认为苹果不太适合我。