1. [Constrict](https://my.supernotes.app/?preview=f04ea500-76c1-429e-bce4-9bfc9cccaee6)
2. [Mid](https://my.supernotes.app/?preview=54593998-52de-4678-81d6-dfee710d3bb4)
3. [Retract](https://my.supernotes.app/?preview=ec86fda3-ec5c-409e-927e-a4f4fb91daf8)



