**Examiner: Do you think single sex schools are still relevant in today’s world?**

*Emilie: While today many would argue that traditional  schools which only allow either girls or boys to study there seem rather **outdated** and old fashioned as this is not how ‘real’ society of the workplace operates. However, many **league tables** which rank schools in order of high exam results, have proved that single sex schools can be much better as there are less **distractions** and maybe students are more able to focus on learning and be proud of their achievements without having to compete with the opposite sex.*

**Examiner: What are the benefits of a boarding school?**

*Helene: As an **alumni** of a **boarding school**, I can see the upsides as well as the challenges. In some countries children as young as 8 are sent away to school, either because of the higher standard of education on offer, or because their parents may be working overseas.*

*Many of these schools offer a wide range of **extra-curricular activitie**s such as golf, photography or fashion as well as the core academic subjects. Children usually speak of forming lifelong friendships, with their **peer group** as well as teachers and there is a strong concept of shared experiences.*

**Examiner: What are the advantages of studying a distance learning course?**

*Lydia: For many people, especially  students who work or need more flexibility, distance  or  [**remote learning**](https://www.ieltspodcast.com/studying-remotely/)  is the ideal way to study. There are several benefits that immediately come to mind. Not only  the cost, which  is far less than it would be to attend a college with **high tuition fees** but the ability to study at your own speed.*

*It is usually agreed that some find that this method of learning suits them better than sitting in lectures or going to tutorials which demands more self-motivation and discipline.*