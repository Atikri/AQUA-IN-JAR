[第一章： 名词和主谓一致](https://my.supernotes.app/?preview=2d9ac2e1-a6ea-466c-bd12-397d58408d70)
[第二章： 冠词和数词](https://my.supernotes.app/?preview=6e90c5de-cec9-4dcc-adfd-eb5c3893030d)
[第三章： 代词](https://my.supernotes.app/?preview=e836addc-d89e-4cb4-a99e-c25a1382c77c)
[第四章： 形容词和副词](https://my.supernotes.app/?preview=c96f944f-4c86-4c80-b298-9e9ee5641eba)
[第五章： 情态动词](https://my.supernotes.app/?preview=ee0e9466-897a-419f-baf8-e745911b41b6)
[第六章： 动词的时态和语态](https://my.supernotes.app/?preview=ec4ec243-062e-43ed-a677-5973e2d411b5)
[第七章： 虚拟语气](https://my.supernotes.app/?preview=5cb05091-756f-49d6-98bb-3245216bb5dd)
第八章： 动词的非谓语形式
[第九章： 介词](https://my.supernotes.app/?preview=b8ae9048-839f-4d41-8be2-156aa804f320)
[第十章： 简单句](https://my.supernotes.app/?preview=5c9e369f-24e3-42b3-a418-6fb5a3309d4f)
[第十一章： 复合句](https://my.supernotes.app/?preview=255e5041-b1a7-482e-a715-58d948837d2a)
第十二章： it的用法和There be句型
第十三章： 倒装
第十四章： 日常交际用语