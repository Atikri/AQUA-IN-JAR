How to Remember What You Read   --「Shane Parrish」
> https://fs.blog/remember-books/
---
Why books donʼt work   --「Andy Matuschak」
> https://andymatuschak.org/books/
---
The Erosion of Deep Literacy   --「Adam Garfinkle」
> https://www.nationalaffairs.com/publications/detail/the-erosion-of-deep-literacy
---
The Commonplace Book: How to Get Compound Interest on Your Ideas -- 「Richard Meadows」
> https://thedeepdish.org/digital-commonplace-book/?nab=3