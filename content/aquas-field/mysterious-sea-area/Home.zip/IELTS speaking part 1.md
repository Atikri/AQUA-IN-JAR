## IELTS speaking part 1 - sample questions and answers

**Examiner: Do you come from a large family?**

!!*Answer: My **immediate family** is not very big. I have a large **extended family** that includes many uncles, aunts, and cousins. We are a **close-knit family**, and we like to **keep in touch** with one another, so birthdays, and other celebrations, are noisy crowded affairs.*!!

**Examiner: When was the last time you had a family function?**

!!*Answer: Our extended family **got together** last year to celebrate my grandfather’s eightieth birthday. He is **very dear to my heart**. He has kept up **healthy relationships** with the whole family, so it was a happy occasion that we all enjoyed.*!!

**Examiner: Would you take a friend on a family holiday?**

!!*Answer: I have. My family and my best friend **got to know each other quite well**, as she visited me quite frequently at my home. My family believes that we should **nurture our friendships**, so they encouraged me to bring my friend along when we took a seaside holiday last year.*!!