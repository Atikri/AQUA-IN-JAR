## 1.Matcha Bowl
### Ingredients:
- Rolled Oats
- Milk
    - [ ] Almond Soymilk
    - [ ] Chickpea Milk
- Coconut Matcha Granola 
- Coconut Water 
- Crunchy Coconut Matcha Cashew Butter 
- Coconut Flakes 
- Deep Green Organic Matcha
- Mixed Green Powder
- [ ] Organic Hemp Hearts 
- [ ] Chia Seed
- [ ] Organic Pure Hemp Protein Powder

---
![IMG_20250612_090620.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/730dac1a-d377-44cd-a6be-f571f7f9c5b9--IMG_20250612_090620.jpg)