- 到校时间：15：00
- 上课内容：检查Sophia老师布置的作业。预习下一单元的单词，以及本课知识点：==主观点，main idea，以及分论点。学会区分主观点和分论点，对于文章概念和结构会有一个很好的帮助。==
---
## how are things different now from long ago
![1000001488.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/8bf7df2f-104a-4971-8a46-2e46d6cb2992--1000001488.png)

==注意communication，Internet读音。==

# 预习课文
![1000001490.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/3fbeb0ee-5e01-4f8b-8022-c856cae83726--1000001490.png)
# then and now