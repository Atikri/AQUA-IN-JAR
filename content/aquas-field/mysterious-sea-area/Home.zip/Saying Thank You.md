Why do people need to say 'thank you'? 
On what occasions do you say 'thank you'?
Do people in your country often say 'thank you'?
Have you ever sent a thank-you card to others?
---
Appreciate (verb) – to recognize the value of something. → It’s a nice way to show you appreciate something.
Commitment (noun) – a promise or obligation to do something. → Without the commitment of buying a gift.
Resource-intensive (adj) – requiring a lot of resources (time, money, effort). → Not everything has to be so resource-intensive.
Expected (adj) – seen as normal or socially required. → It’s certainly expected.
Polite (adj) – having good manners and showing respect. → I always try to be polite to people.
Minimal fuss (phrase) – with little disturbance or difficulty. → Let me pass them in a street with minimal fuss.
Give someone a hand (idiom) – to help someone. → They say thank you when I give them a hand.
Thank-you card (noun) – a card sent to express gratitude. → Have you ever sent a thank-you card?
Goodbye present (noun) – a gift given when parting ways. → I would have at least given her a goodbye present.
Let someone stay (phrase) – to allow someone to live with you temporarily. → She let me stay with her for a few weeks.
Gratitude (noun) – the feeling of being thankful. → Expressing gratitude can improve relationships.
A token of appreciation (phrase) – a small gift or gesture to show thanks. → He gave me flowers as a token of appreciation.
Manners (noun) – socially accepted behavior. → Children should be taught good manners.
Acknowledge (verb) – to recognize or admit something, especially help or support. → It’s important to acknowledge others’ efforts.
Reciprocate (verb) – to return a favor or show the same feeling in response. → When someone helps you, it’s polite to reciprocate.
---
Maria: Why do people need to say thank you?

Rory: Well, I suppose it's a nice way to show you appreciate something that someone's done for you, but without the commitment of buying something like a gift. Not everything has to be so resource-intensive, does it? I don't know if they need to do it, but it's certainly expected.

Maria: On what occasions do you say thank you?

Rory: Oh, wow. It would be easier to say when I don't, to be honest. I always try to be polite to people, especially if they help me out, even in a minor way. And so that could be anything like when they hold the door or let me pass them in a street with minimal fuss.

Maria: Do people in your country often say thank you?

Rory: I think so. They certainly seem to when I make the effort to give them a hand, although certain older people seem to think that people in general are less thankful than before. Maybe it was different back then. I have no idea.

Maria: Have you ever sent a thank-you card to others?

Rory: Oh, God. Well, I must have at some point, I suppose, though I can't remember exactly when. I think it might have been when I left… Yeah, I left one of my friends after she let me stay with her for a few weeks, and that was really nice of her. So I think I probably sent something then. And if I didn't, I would have at least given her a goodbye present. And if not, then I can say it now. Thank you, Cheeway, for letting me stay with you when I was in Kyrgyzstan doing different things.