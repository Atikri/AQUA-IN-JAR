The criteria of fluency and cohesion for band 7 indicates that the candidate should **use a range of connectives and discourse markers with some flexibility**. Let’s discuss what are discourse markers and connectives, what is to use them with flexibility and how to achieve that flexibility in your exam answer.

In order to sound convincing and confident your speech needs to be both connected and logical.

This can be achieved in speech by using a number of special words and phrases called connectives or linkers.

Very often they are also called discourse markers, though some sources still specify that discourse markers’ function is to actually show the listener that we are going to show attitude, introduce opinion, rephrase, repeat or change what we are saying. Anyway, both groups of these words help to make what we say clearer for the listener and add order and structure to your answer.

**Connectives** are words or phrases that connect and relate sentences and paragraphs. They help to build the logical flow of ideas as they signal the relationship between sentences and paragraphs. You can see some of the more commonly used connectives in the table below.

These words and expressions help to develop, relate, connect and even **move** **ideas**.

The table below lists a few of the most frequently used connectives.
Connectives
| FUNCTION | CONNECTIVES |
|---|---|
| addition | and, also, besides, furthermore, too, moreover, then, equally important, another |
| comparison | like, in the same manner (way), as so, similarly |
| contrast | but, in contrast, conversely, however, still, nevertheless, yet, on the other hand, on the contrary, or, in spite of this, actually, in fact |
| order or sequence | first, second, (etc.), finally, next, then, to begin with, after, before, as soon as, in the end, gradually |
| results | as a result, so, accordingly, consequently, thus, since, therefore, for this reason, because of this |
| purpose | for this purpose, with this in mind, for this reason |
| to signal an example or emphasize | for example, to illustrate, for instance, to be specific, such as, especially |
| to summarize or conclude | in summary, to sum up, to repeat, briefly, in short, finally, on the whole, therefore, as I have said, in conclusion, as you can see |

Discourse markers
| FUNCTION | Discourse markers |
|---|---|
| To preface what you really think | Actually, I have to say |
| To confess that something is true | I must admit |
| To give yourself time to think | Well |
| To start, end or change topic | Right, so, anyway |
| To say something in another way | What I mean is, in other words |
| To talk about knowledge we share with listener | You know, you see |
| To introduce personal opinion | My point is, what I’m getting at is, I mean, I guess |

A piece of advice for those who want to attain a band 7 answer would be to use a good variety of both connectives and discourse markers, to avoid repeating them and not to use only the basic ones (*like and, or, but, however, in my opinion*). This is exactly what the exam criteria of using them “**with flexibility**” refers to.

Now let’s have a look at the good answer and the function of each connective in context.