[Effort](https://my.supernotes.app/?preview=988ee57b-88e4-4d40-8dfc-ffc1aa8fa433) 
voice of qualities
[True Vocal Fold:Onset /Offset](https://my.supernotes.app/?preview=adcd4f12-2121-44f4-a467-9c9d440506d3)
[False Vocal Fold](https://my.supernotes.app/?preview=cc264590-3408-4166-ab8d-b37f4c4cbfb7)
True Vocal Fold:Body-Cover 
[Thyroid Cartilage ](https://my.supernotes.app/?preview=2a66a2e7-ee2d-4fbf-a336-d76821911301)
Cricoid Cartilage 
Aryepiglottic Sphincter
[Larynx](https://my.supernotes.app/?preview=cd1734c4-7b28-40ba-87b2-07003fb85761)
[Tongue](https://my.supernotes.app/?preview=c0a69a36-a7f4-465c-936b-4a0ec5d27e7e) 
Velumn 
Jaw
Lips
Head&Neck
Torso