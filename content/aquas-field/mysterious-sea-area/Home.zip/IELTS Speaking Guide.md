# Part 1：
|Band 5.0-6.5|Band 7.0-9.0|
|---|---|
|Memorized answers <br>  死记硬背答案 </font>| Feels like a normal conversation <br> 给考官感觉像是非常自然的交流对话|
|Very long answers <br> 过于冗长的答案 |Answer Q directly <br> 直截了当回答问题|
|Off-topic <br> 回答离题 |Developing their answers enough , but not going off-topic. <br> 很好的发展口试问题，但不会离题|
|Very formal (Robotic) <br> 表达太过正式（过于书面），给人感觉像是机器人|Naturally <br> 自然口语化的表现形式|


## Part 2:
|Band 5.0-6.5|Band 7.0-9.0|
|---|---|
|Rigidly follow the buller points <br> 机械式的按照考官给的回答要点进行阐述|Use the buller points to help them speak naturally <br> 巧妙的运用考官所给的回答要点将自己阐述的内容自然得串联起来|
| Use a trick <br> 用一些看似聪明的小伎俩但并没有回答到要点上|Focus on the main topic <br> 聚焦于主要话题上 |
| Run out of ideas <br> 过于满溢的想法 |Speak naturally about the main topic for 2 mins <br> 很自然的就主题谈论两分钟足矣 |

## Part 3:
|Band 5.0-6.5|Band 7.0-9.0|
|---|---|
|Very short answers <br> 过于简陋的答案|Lots of development <br> 有对于话题的深度思考衍生|
|Might not attempt some answers <br> 可能不会尝试一些角度的回答方式 | Attempt every question <br> 敢于尝试各类问题题型的回答| 
|The range will be limited <br> 对于一些主题话题会感觉无从下手|No problem talking about a range of different topics <br> 就算谈论一系列不同主题的话题也信手拈来|