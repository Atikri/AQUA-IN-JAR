- Presence of mind 
!!The ability to remain calm and take quick, sensible action in a difficult situation.!!