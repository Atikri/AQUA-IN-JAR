## **[IELTS speaking part 2](https://www.ieltspodcast.com/ielts-speaking/ielts-speaking-part-2/) - style question**

- **Describe an experience or meeting you had at university.**

**You should say:**

- **what it was**
- **when you had this experience or meeting**
- **where you had this experience**

**and explain why this experience/ meeting had an impact on you.**

**Sara:** *I would like to talk about my own personal experience studying at a **further education college** in Germany a few years ago. I had enrolled at a **technical college**, as I was looking for a practical, **vocational course** in order to learn more about engineering and I had hoped that this course would include an element of hands-on training as well as formal classroom learning.*

*When I arrived at the college, I was allocated a place at a hall of residence which I had thought would be located close to the lecture theatres, however in fact, it was a 30-minute bus ride away. This was a disaster as far as making friends was concerned – it made it very hard to get involved in a **university social life**, which everyone knows is meant to be exciting and great fun.*

*At one of the seminars in our first month, I explained my accommodation issue to one of my new tutors, a very kind professor who was one of the leading experts in her field, and she was very sympathetic, and fully understood that this hall of residence was located a long way from the student’s union and other student areas.*

*Suddenly, while we were talking, her eyes lit up, like she had had an inspired idea! She explained that she was looking for a lodger or tenant as she lived in a large, empty house and she offered me the chance to rent a room in her house which I gratefully accepted.*

*For the next three years, I lived in central Berlin with this incredibly wise, kind and intelligent professor. She challenged and motivated me to study as hard as I could, as at one point I had considered dropping out because I was rather out of my depth in some of the technical detail of the course, and when I finally graduated, she was cheering the loudest at my **graduation ceremony**.*

*I was very lucky to have formed such a strong bond with this amazing teacher and the impact she had on me was life-changing as now I intend to specialise in the same field as her.*