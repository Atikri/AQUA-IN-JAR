# Welcome to ~AQUA~IN~JAR~

Hi! I'm Tikri~

Through the **self-generated** power of the voice, I aim to explore and implement practices in daily communication, emotional expression, public speaking, singing, and personal growth. My goal is to collaborate with others to deepen self-awareness and cultivate individuals who are both strong and flexible.