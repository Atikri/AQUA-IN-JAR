## **Understanding the cue card in IELTS Speaking part 2**

The first thing that you need to do is look at the structure of the cue card. It is divided into three parts. Take a look at this IELTS speaking part 2 topic.

**Talk about an older person you admire**

**You should say:**

**who this person is**

**how long you have known him/her**

**what qualities he/she has**

**And why you admire him/her**

Let’s take a look at these three parts:
## **Part 1 – The topic**

This basically means the subject you are going to talk about. For example, it could be a book, a film, a meal or in this case a person – **Talk about an older person you admire**. There are many topics connected with people so it is a useful topic to look at, as the vocabulary here could be used in many IELTS ‘Talk about a person who…’ speaking topics.

It is important to remember that:

It is always going to be a general topic – not an academic topic, it is not a test of your knowledge

It will be about something personal to you – something **you** have done, someone **you** know

## **Part 2 – Describing the topic**

This part focuses on the three questions:

- **who this person is**
- **how long you have known him/her**
- **what qualities he/she has**

In this part, the questions are always asking what, when who or where and they require you to give detailed information. The mistake many candidates make here is to simply answer these three questions and after about thirty seconds they cannot think of anything else to say. It is important that you add detail to these questions so for example, you could talk about how you met this person.

## **Part 3 – Answering the ‘how/why’ question**

This is often the hardest part because here you have to explain and explaining is harder than describing. In this topic, you need to explain ‘**why you admire him/her**’.

This part gives you the opportunity to say more, as explanations are usually longer than descriptions, however, they are often harder. This requires more thinking on your part, but if done well can help you to achieve a high band score.

## **Ok, so now I understand the cue card, how do I make notes?**

I’ll start by telling you what not to do and unfortunately, it’s the thing that the majority of IELTS candidates tend to do…

**DO NOT TRY TO WRITE YOUR ANSWER WORD FOR WORD!!!**

As soon as the IELTS examiner says ***‘Your one minute starts now’***, many candidates start writing…

*‘The person I am going to talk about today is my friend. His name is Mike and I have known him for seven years.’*

Then the voice of the IELTS examiner says:

**‘Please can you start speaking now please.’**

A look of fear appears on the candidate’s face because they are thinking *‘oh no, I haven’t got enough to say****’***. They start reading what they have written and ten seconds later… silence and panic!

**SILENCE GETS YOU NOTHING IN IELTS SPEAKING!!!**

## **What should you do?**

Only make notes that are going to get you a high band score

I have seen candidates write the words ‘nice’ or ‘fun’ – that’s fine if you want IELTS 5.0, but if you are aiming for higher, then you need to write words that are going to impress the IELTS examiner.

**And remember…**

You only have one minute

So this means, realistically you can only write five or six words/phrases. ‘*That’s not enough’*, you are probably thinking, well it’s what you do with the words that is important.

My notes for answering the topic ‘**Talk about a person you admire…**’ would be:

*A born leader*

*Entrepreneurial skill*

*Determined*

*Charismatic, charming*

*Well-respected*

*Inspirational/a positive role model*

These words/phrases are all going to impress the IELTS examiner because they are much more complex than ‘nice’ or ‘fun’.

## **Practise using more detailed notes**

Instead of just writing down words, you could also try thinking of more detailed phrases/ideas so for example for the question ‘**how long have you known him/her**’, the tendency is to answer this by saying *‘****I’ve known him for 6 years****’*, but again this is not going to impress the IELTS examiner.

Something like *‘****I’m not entirely sure when we met, it could have been about seven years ago… yes that’s right, it was when we were both playing football for the school team…****’* is much longer, more detailed and contains much more complex language that you need for IELTS 6.5 and above. The notes that you would write down might be:

**I’m not entirely sure…**

**…it could have been**

**…we were both playing football**

Remember that IELTS Speaking is not a test of knowledge, it is a test of communication so the more language you can use to communicate, the same way you would in your native language, the more it will impress the IELTS examiner. Don’t just sit there like a robot answering the questions!

## **Answering the ‘reason’ question – that tricky last question on the cue card**

The last part of the cue card is the ‘how/why’ question and it is the part where you should have the most to say. It is, however, the most difficult part. You need to think of a few words/phrases that you can use in this part e.g. inspirational, a positive role model.