https://www.instagram.com/reel/DLKukqJSore/?igsh=MTlveHNueG5yOWlobA==
熟透的香蕉皮摩擦面部。之后静待十分钟用温水洗净
- [ ] day 1
- [ ] day 2
- [ ] day 3
- [ ] day 4
- [ ] day 5
- [ ] day 6
- [ ] day 7