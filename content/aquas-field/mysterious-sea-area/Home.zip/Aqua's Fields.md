## Reference Resource:
[Areas](https://my.supernotes.app/?preview=0b06e06e-bc0e-4e9a-9872-133536504c28)
[System](https://my.supernotes.app/?preview=81c80330-8d36-433a-9f7b-1b5a4c272def)
---
## Fields:
### SOIL
* Basic/Self-generated
* [Exercise](https://my.supernotes.app/?preview=4dfa1245-8f2d-4a5c-bc5b-9bdbaf899b59)
     > DAILY EXERCISE :runner: 
* Health 
    * Recipe
    *  Diet Healthy Knowledge
* Sleep
     > SLEEP BEFORE 22:30 :sleeping_bed: 
* Mood
* Clothing
* Music
### FRUITS
* Financial
* [AI/Internet ](https://my.supernotes.app/?preview=e25a545f-f627-48e1-be9c-61e647a797bc)