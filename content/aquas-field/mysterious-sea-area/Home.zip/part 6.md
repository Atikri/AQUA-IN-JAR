### **Examiner: Describe one of your best travel experiences.**

This type of question supports a when, where and who reply.

*Answer: Last year a friend and I took a* ***long-haul flight*** *to Peru. We were* ***travelling light*** *so we were able to really* ***get around****. We stayed in* ***quaint villages*** *and hiked through* ***lush rainforests****. We were determined to* ***do as the locals do****, rather than go on guided tours, so we stayed with local people for part of the trip.*

*We visited colourful* ***craft markets*** *and brought back souvenirs, to remind us of our trip. One of my most* ***memorable experiences*** *was to the Sacred Valley of the Incas. It is a little bit* ***off the beaten track*** *but it is surrounded by great* ***scenic beauty*** *and* ***magnificent landscapes.***

### Examiner: **Describe a city that you think is interesting.**

**You should say:** 

- where it is
- what it is famous for
- how you knew this city
- explain why you think it is very interesting


### **Examiner: Describe a tradition in your country.**

**You should say:** 

- what it is
- who takes part in it 
- what activities there are 
- explain how you feel about it