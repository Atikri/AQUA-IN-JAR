:grinning: :fried_egg: 
---
- **Dusting** (noun) – the act of removing dust from surfaces. → She did some quick dusting before the guests arrived.
- **Cleaner** (noun) – a person whose job is to clean homes or buildings. → We hired a cleaner to tidy up before the party.
- **Housework** (noun) – tasks such as cleaning, washing, and ironing that are done in the home. → He shares the housework with his flatmate equally.
- **Process** (noun) – a series of actions taken to achieve something. → Cleaning is a time-consuming process.
- **Eats into** (phrasal verb) – takes away too much time, money, or resources. → Commuting eats into my evening time.
- **Pointless** (adjective) – having no meaning or use. → It felt pointless to clean the windows right before a storm.
==- **Homeostasis** (noun) – a stable, balanced state; used figuratively here to mean a tidy, ideal condition. → A house rarely stays in perfect homeostasis.==
- **Sweep** (verb) – to clean a floor using a broom. → I sweep the kitchen floor every evening.
- **Ideally** (adverb) – in the best possible way or under perfect conditions. → Ideally, I’d have someone else do all the chores.
- **Finicky** (adjective) – requiring great attention to detail; difficult to please. → Dusting delicate ornaments is such a finicky job.
- **Task** (noun) – a piece of work that needs to be done. → Vacuuming is just another boring task on my to-do list.:grinning: 