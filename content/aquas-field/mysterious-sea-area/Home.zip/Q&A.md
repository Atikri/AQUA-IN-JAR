M: Rory, do you like to take photographs?

R: Well, I wouldn't mind taking them. But I wouldn't go and haven't gone out of my way to do either. I really tried to live in the moment these days and stopping to take a few snaps even for a moment tends to ruin the flow of that.

M: Which kind of photos do you like to take?

R: Well, I suppose there are two kinds. Ones that other people will definitely find interesting, or ones that can help me remember things without having to take up much space. So that would be things like scenic views of my home for my friends who live abroad, or ones of keepsakes that are a bit too bulky to carry with me. But once that I like to remember anyway, I think those kinds of photographs are quite practical.

M: How did you become interested in photos?

R: I haven't, though, when I do feel the need to take them, it's because the occasion calls for it or the situation demands it.

M: How do you keep your photos?

R: I have a few albums on my computer and drives, and they're organized by year. We also have some physical albums around the house that are organized by certain events or themes, but usually, they're just organized by the times they were taken.

M: Do you ever delete or throw away photos if they are on paper?

R: Well, if they're, I don't know, redundant or ruined, then there's no point keeping them. Otherwise, I prefer to hang on to them.

M: Will you take more photos in the future, do you think?

R: Well, I'll take photos. I don't know if I'll take a larger number than I have on average before. It's a bit of a strange thing to think about.