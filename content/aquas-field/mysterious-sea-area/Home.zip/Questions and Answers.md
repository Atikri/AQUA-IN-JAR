Rory: Well, I think in Scotland, we're quite fortunate to have someone like James MacLeod, who is an environmental activist dedicated to preserving our country's natural beauty. He spent the last decade tirelessly working to combat deforestation and promote sustainable land management and just raise general awareness about climate change. His commitment seems unwavering. Every weekend, he leads volunteer groups on tree planting expeditions to the Cairn Gorms National Park. That's a large national park in our country, it's in the north. And they restore areas affected by things like illegal logging and soil erosion. And then on weekdays, he collaborates with local councils and NGOs on policies that prioritise things like renewable energy and the protection of endangered wildlife, or what's left of it in this country anyway. Not only does he do hands-on conservation work, he frequently delivers lectures at universities, which must be quite inspiring for young people when it comes to taking action.


I think one of his most remarkable achievements was his successful campaign to re-wild one of the valleys in our country, though through some pretty relentless fundraising, he managed to secure government support, which allowed thousands of native trees to be replanted and natural ecosystems to thrive once again. His work hasn't gone unnoticed by others, thankfully, since he's, I think, received multiple awards for his contributions. There was one in the papers the other day, now that I think about it.


I don't know much about his motivation, but I suppose it probably stems from some sort of deep-seated love of our country's natural heritage, and he's made it his life's mission to reverse the damage done to the environment and educate others on the subject. If we didn't have him around, I think we would be much worse off.


Maria: And do you know many friends who protect the environment?


Rory: I think we all contribute at least a little bit, but not as much as this person.