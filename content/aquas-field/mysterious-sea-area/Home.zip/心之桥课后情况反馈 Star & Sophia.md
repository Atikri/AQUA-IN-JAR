- 到校时间：9：40:clock9: 
- 上课内容：Oxford Discover Book 1：Unit 2／11 reviews＆Unit 12 words and reading《Wants and Needs》:book: 
- 优势：:smiley: 
    - Sophia：阅读流畅度很快，对于图片的感悟能力强
    - Star：会努力回想上课上过的内容，并且积极应答

- 提升：:blush: 
    - Sophia：容易被课本文字外的其他事情比如插图等吸引导致注意力不集中。
    - Star：比较好动，导致之前讲的内容没有听明白。
    - 此外，两个小朋友在各自读自己的内容时，另外一个小朋友会分心，希望两位小朋友在没有读自己的内容时也能倾听对方读的内容！

- 作业：:mortar_board: 
    - 1.完成unit 12 单词的复习朗读通顺即可
    - pretty,comic,mix,different,healthy,also,important,food,store,service,police officer,vegetable.
        - people的单数:point_right: !!person!!
        - we的物主代词:point_right:!!our!!
        - ![1000000297.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/2d44b495-3965-4d8d-b48f-c423ca67b9c0--1000000297.jpg)
    - 2.试着理解reading《Wants and Needs》中文章所表达的意思

- 日期：2025.2.13 :date: 