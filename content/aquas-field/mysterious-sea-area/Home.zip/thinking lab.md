[如何度过一天，度过四季](https://my.supernotes.app/?preview=f7362db8-237c-42a6-ac10-317716ee1a0f)
[測試「不可能的事」：改變我人生的17 個問題](https://my.supernotes.app/?preview=e3103c86-e34f-4e23-a351-80f0a99a9690)
我们的消费社会
# 事业洞察
# 周刊：
## Vol.29 摘下面具，誠實地成為你自己！
[卡爾·羅傑斯：如何摘下面具，成為一個真實的人？](https://my.supernotes.app/?preview=27bc7976-a943-4775-bf71-6d4fbee01de7)
## Vol.30 如何停止在意別人的看法？
[馴服你心中的猛獁象：如何停止在意別人的看法？](https://my.supernotes.app/?preview=b599e853-ac3c-455e-bf5a-d7402e676733)
[傾聽內心深處的傷痛：內在家庭療法與慢性疼痛](https://my.supernotes.app/?preview=3719f702-dd1d-48d0-ae1d-1a85b11ddaff)
## Vol.36 如何科學地建立你的晨間 Routine？
[5個日記問題：用寫日記來重建生活秩序](https://my.supernotes.app/?preview=35b06a83-849b-4478-a7f7-4c81ea641d79)
[5小時法則：如何把虛度的一天變成充實的一天](https://my.supernotes.app/?preview=ae731bd4-ad87-4e6d-9eea-fb1102b50918)
[起床后1分鐘的習慣，將徹底改變你的生活](https://my.supernotes.app/?preview=c999415f-4dca-45bc-a2aa-b76417f4089c)
[深度工作：如何用6個月重塑生活？](https://my.supernotes.app/?preview=8ed03b05-07a6-458f-ab45-c6733c41b036)
[關於睡眠、運動、糖和癌症的7大誤解](https://my.supernotes.app/?preview=658a0ccc-a124-41bd-81df-904ae69b27ef)
[如何科學地制定你的晨間Routine？](https://my.supernotes.app/?preview=36165c30-ba97-4fd3-9f3a-852749a72607)
## Vol.48 如何突破認知的習得局限？

## Vol.54 人怎樣才能真正改變？
[人怎样才能真正改变?](https://my.supernotes.app/?preview=7ff99ea3-d441-4d97-87f5-ffbc59a33c91)
[如何过上充满智慧的生活](https://my.supernotes.app/?preview=88cf8f31-4cb9-41c1-8c07-add5c5f9925e)
[Steve Pavlina 的時間管理技巧：Do It Now](https://my.supernotes.app/?preview=9617424d-36e5-407d-aea5-c13a77c1f844)
[追求富有成效的生活：我的個人基礎設施解密](https://my.supernotes.app/?preview=5b7981e0-07e5-4e06-9c02-91a41d9f027f)
## Vol.57 把神经科学变成日常实践：优化你的睡眠、情绪、动力
# 月刊：
## Vol.4 如何打造你的"第二大腦"？
[如何打造你的「第二大腦」？](https://my.supernotes.app/?preview=65d76281-93d3-4f56-8bab-b2935cdc8d8d)
[P.A.R.A方法：在幾秒鐘內組織數位生活的簡單系統](https://my.supernotes.app/?preview=0b06e06e-bc0e-4e9a-9872-133536504c28)
[漸進式總結1 ：起源與定義](https://my.supernotes.app/?preview=cfbc020e-c681-482f-8186-575cbdf9556d)
[漸進式總結2 ：案例與隱喻](https://my.supernotes.app/?preview=a999a9b7-4358-48df-831d-490966ab0734)
[漸進式總結3 ：四個核心原則](https://my.supernotes.app/?preview=02aa26ee-c05c-44e7-9f3d-bda7017c70d9)
[漸進式總結4 ：如何對多媒體內容進行漸進式總結](https://my.supernotes.app/?preview=0ddd356b-c9c3-4cc8-a51b-8ff8ee2b00b6)
## [Vol.11 如何好好休息？](https://my.supernotes.app/?preview=2fefaad3-b60d-4cbe-9868-ae1a2f6630e0)
[何謂休息？](https://my.supernotes.app/?preview=1248eea7-4b9c-4842-a02e-a5c75703441c)
## Vol.12 Thinkinglab 2024年十佳文章
[資訊繭房自救指南：我們如何面對資訊過載](https://my.supernotes.app/?preview=09cff893-fb34-444b-ade6-f581c55cf1f0)
[學會建立自己的系統，而不是目標](https://my.supernotes.app/?preview=81c80330-8d36-433a-9f7b-1b5a4c272def)
