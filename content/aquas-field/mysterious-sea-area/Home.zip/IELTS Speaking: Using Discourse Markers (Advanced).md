In this tutorial you will learn:

- Discourse markers

This will help you in your IELTS speaking exam because:

- You’ll be able to use discourse markers in part 3 of IELTS speaking.

If you are struggling with the Speaking exam, or just want to improve faster, have a look at the Speaking Confidence course (included in the Jump to Ban 7 or it’s Free writing course).

**What are Discourse Markers?**

When answering the speaking examiner’s questions, you’ll want to make use of discourse markers to show fluency and cohesion.

Discourse markers or signposts as they are sometimes called, are words or phrases that make it easier to identify attitudes or changes of direction and perspective in a conversation.

Most people who are at least at an intermediate level of English already know how to use basic signposting such as: ‘’in my opinion,’’ ‘’finally,’’ and ‘’next.’ However, here are some examples of less commonly used discourse markers for linking ideas and signposting ideas:

**What are examples of** **Discourse markers?**

**Expressing agreement**

- Absolutely….
- Certainly…..
- Definitely…..
- Well actually……

**Expressing an attitude**

- To tell you the truth…..
- I must admit…..
- To be honest…..
- Ideally…..