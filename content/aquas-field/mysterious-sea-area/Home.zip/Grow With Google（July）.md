## Step 1:
[Google Ads 搜尋廣告認證](https://my.supernotes.app/?preview=18da5f8e-bb4e-45f8-ae6f-7520e74e6f42)
[Google Ads 影片廣告認證](https://my.supernotes.app/?preview=fd1631a7-d2b1-46cf-b716-116f136ac32c)
[Google Ads 廣告素材認證](https://my.supernotes.app/?preview=227356b3-d933-4385-9c51-95007a6d47d1)
[AI 技術輔助高效廣告認證](https://my.supernotes.app/?preview=2c6f35f6-5416-4c42-a2db-6a4a4f7dc0a2)
[Google Analytics (分析) 認證](https://my.supernotes.app/?preview=e24bfc81-3ef8-4833-8c1a-dea10191cbc9)

## Step 2:
Introduction to Generative AI
Introduction to Large Language Models
Introduction to Responsible AI