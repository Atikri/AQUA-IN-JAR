What kind of apps do you spend money on?
What apps don't you use anymore? 
What apps do you still use? 
What kind of apps have you downloaded on your phone?
---
- **Subscription fee** (noun) – a regular payment (monthly or yearly) for using an  [app](https://successwithielts.com/s12e01#) or service.
- **Negligible** (adjective) – so small that it's not worth worrying about.
- **Riddled with** (phrase) – filled with something negative (like ads or errors).
- **Stopped using** (verb phrase) – no longer using something.
- **Be caught dead** (idiom) – would never do something because it's embarrassing or unpleasant.
- **Waste of time** (noun phrase) – something not useful or productive.
- **Social networking** (noun) – using [apps (https://successwithielts.com/s12e01#) or platforms to connect with others online.
- **Manage** (verb) – to organize or control (like a schedule or task).
- **Publish** (verb) – to share something publicly, especially online.
- **Stick to** (phrasal verb) – to keep using or doing something without changing.