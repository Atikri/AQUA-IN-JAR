## Date:
> 2025.6.22
## Guest:
> 金星
## Songs:
> 山水之间
> ---
> moving on pedals 
> 神爱世人
> 成婚破浪
> shattered
> 小夜灯
> 毋忘
> 

## :grinning: 
![d7c92fcd41ed82f33f06d80eb7db31c.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/e1eb8465-2031-4b78-af01-845d1d85518b--d7c92fcd41ed82f33f06d80eb7db31c.jpg)
## 推荐的黑客类游戏：
- Nite Team 4
- One dreamer
- Hacknet
- midnight protocol