Maria: What kind of music do you like?
Rory: Oh, wow, that's a rather mixed bag, really. I don't have one favourite genre or anything. What I do, actually, is tend to latch on to specific songs and listen to them on repeat for ages before moving on to something else.
---
Maria: What musical instruments do you enjoy listening to the most?
Rory: I think that depends on the context, really. But generally, piano or other instruments you might find in an orchestra, they're quite pleasant to listen to, at least in my opinion. Of course, I also listen to rock music, so someone jamming on a guitar can be quite fun as well when the occasion calls for it.
---
Maria: Do schools in your country have music lessons?
Rory: As far as I'm aware, yes. It's one of the core areas of the curriculum, so students get the chance to enjoy and participate in a variety of music-related activities. What they all are, I have no idea.
---
Maria: Have you ever learned to play a musical instrument?
Rory: Oh, I used to know how to play the recorder. That's a kind of instrument that's very similar to a flute, except it's got a different mouthpiece. And I made an effort at learning to play a few guitar chords, but I'm not like a maestro or something.