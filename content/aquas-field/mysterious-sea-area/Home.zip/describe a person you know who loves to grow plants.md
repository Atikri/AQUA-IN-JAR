## you should say 
- who this person is 
- what he or she grows 
- where he or she grows these plants 
- and explain why this person enjoys growing plants
---
be a dab hand with/at something：这是一个固定搭配，表示“擅长于某事”。
botanist 植物学家
greenery 绿色植物
the exact name escapes me since I'm not that great with growing or knowing much about plants
pop up
shrivel up  - 枯萎，凋谢
because it makes the place look nice and makes it feel a bit less sterile.（无菌的，缺乏生机的，不那么单调）
plant murderers 植物杀手
So you can say that he's not a botanist, but he enjoys botany.
But we can remember English ivy.
但我们能记住英国常春藤。
Or, for example, African violet is a flower.
或者，例如，非洲紫罗兰是一种花。
As far as I know. Repotting. But the plants make the place look nice. It's all green.
据我所知。换盆。但是植物让地方看起来很漂亮。到处都是绿色的。
Yeah, you see, we don't even know, because we don't have green fingers.
是的，你看，我们甚至都不知道，因为我们没有园艺天赋。
Yeah, vegetable patch where vegetables grow, or a flower bed.
是啊，菜地里种蔬菜，或者花坛。