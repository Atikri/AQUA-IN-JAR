[Quinoa & eggplant salad](https://my.supernotes.app/?preview=9d3e0597-8cd0-48db-af19-1ebdb445a2ff) 
[Kale, green beans & roasted broccoli](https://my.supernotes.app/?preview=c93308d0-0d02-4112-8b36-9957d0911326)
[Coconut chia cups](https://my.supernotes.app/?preview=96f2e077-9aaa-4ae9-acde-8bf1f65ec4ed) 
[南非炖菜](https://my.supernotes.app/?preview=37997bc8-f394-488c-aa88-21cec267aa76)
[Coconut, mushroom & pumpkin risotto](https://my.supernotes.app/?preview=0f42d1b9-de92-46b2-9689-ab7d9c50b720)  
[Gozleme with feta & Swiss chard](https://my.supernotes.app/?preview=15b440dc-c648-4677-86b1-e7fb2e2ca281) 
[Cauliflower rice sushi](https://my.supernotes.app/?preview=611c6683-757f-46b3-9653-1b632024f4a1)
Purple cauliflower rice
Almond tabouli