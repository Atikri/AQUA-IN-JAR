M: Do most people prefer to prepare and organize an activity or just take part in an activity?

R: Well, given the stress involved when you have to put things like weddings and parties together, it's easy to see why more people attend them than sort them out. I mean, there's invitations to send out the actual event to manage and the cleanup after. Why would anyone want to do that with any regularity?

M: How do people feel when they are not well prepared for something?

R: Well, I imagine that comes down to the kind of person that you are or the personality you have. Some people don't mind just winging it to an event like a speech or a presentation when they know their subject matter inside out, but other people get so nervous if they aren't ready that they might even be physically sick.

M: Do people need others help when organizing things?

R: Well, I imagine that depends on the scale of the event. No. If it's a small gathering of four or five people, how much help do you need exactly? And then, if it's something like a wedding reception, though, then you need to do a lot more, and might need a helping hand or two.

M: Does everything need to be well prepared?

R: I suppose that comes down to the expectations people have. If you're doing a job for people who have quite high expectations of you, then preparation will be fairly important so you can deliver a good job. But if it's just something for yourself, you can make a mess of it, and you're only answerable to yourself. So it might not matter so much.

M: On what occasions do people need to be organized?

R: Well, anytime they want to maximize their success, probably. In times when you need to get the most out of what you have to work with it's useful to plan in advance and get things ready so you don't waste time and resources faffing about.

M: How can parents help children to be organized?

R: I always think having a good example of living your values works best. So if you want people to be organized, you have to be organized yourself. Otherwise, what's the alternative? Just telling them won't work. They need to see it in action and live the experience to get the hang of it.