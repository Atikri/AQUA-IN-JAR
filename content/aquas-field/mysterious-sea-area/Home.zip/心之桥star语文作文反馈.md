- :timer_clock: 上课时间：1：00-3：00（第四节课）
- :cowboy_hat_face: 上课内容：完成第六篇文章，这儿真美
---
## :bee: star记录的素材
![IMG_20250827_141504.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/67fab644-cc0e-4a9f-92a5-889c662e1205--IMG_20250827_141504.jpg)
---

## :exclamation: star写作主要问题：
- 需要结合文章走线，适当的进行内容的改动以符合通顺度，切莫太注重于事实而导致文章走线过于僵硬。
- 要培养积极思考，主动思考的能力，star不太喜欢主动思考。

---
## 改写后文章：
![IMG_20250827_141514.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/b3a687cf-8134-4e10-bcc7-498070f0636f--IMG_20250827_141514.jpg)
---
==作业：已经对最后一篇文章进行简要概述，star回家可以尝试自己写一下==