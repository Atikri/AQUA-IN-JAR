影片内容市场的转变：不再由影片工作室决定。由创作者和观众决定。
可以瀏覽[這個 YouTube 廣告網站](https://www.youtube.com/intl/en_us/ads/resources/success-stories/)，瞭解規模各異的企業如何透過 YouTube 廣告達成目標。
### **Missouri Star Quick 公司**
目標：知名度
Missouri Star Quick 公司一開始是在 YouTube 中教授拼布縫紉，卻意外發現愛好縫紉的人非常多。因此，他們以觀眾的興趣為基礎來製作影片廣告，希望能觸及大量潛在客戶，像是喜歡觀看手工藝影片的使用者，以及紡織品市場中的潛在消費者。
詳情請觀看[這部影片](https://www.youtube.com/watch?v=QWnOF68HNMk)。
---
### **Nectar by Resident**
目標：考慮度
Nectar by Resident 與 YouTube 攜手合作，按照高效廣告影片的最佳做法製作廣告素材。他們實行嚴格的測試計畫，藉此評估不同的面向並盡可能改良廣告活動 (格式、目標對象、廣告素材長度等)。
接著，他們變成放送長期廣告活動，品牌興趣增加幅度達 382%。
詳情請參閱[這篇文章](https://www.youtube.com/intl/en_us/ads/resources/success-stories/nectar-a-resident-company/)。
---
### **United Airlines**
目標：行動
United Airlines 需要向搜尋過航班資訊的使用者進行再行銷，並鼓勵他們購票。他們製作了 15 秒的影片，呈現出人們在絕美景點享受假期的畫面。接著，他們的行銷團隊採用影片行動廣告活動，建立強而有力的行動號召，直接將使用者帶往網站。
詳情請參閱[這篇文章](https://www.youtube.com/ads/resources/success-stories/united-airlines/)。
---
必須留意三個 YouTube 使用者趨勢：  
1.  **串流**正在崛起。在含廣告連網電視的觀看時間中，YouTube 影片目前已超過 50%。
  
2.  **短片**蓬勃發展。YouTube 推出了短片製作功能，並提供全世界最多的短片，進而成為這個轉變的核心。
  
3.  **線上購物**趨勢持續成長。YouTube 可讓使用者發掘、深入瞭解產品和服務，以及從中汲取靈感，是使用者歷程中的關鍵。

