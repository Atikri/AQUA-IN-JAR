Do you write a lot? 
Do you prefer writing by hand or typing? 
Did you like writing things when you were a child? 
What do you like to write? Why? 
Do you think the things you write would change?
---
Extended (adj.) - long or longer than usual.
To file (verb) - to store information in a careful and particular way.
Handwritten (adj.) - written using your hand rather than printed by a machine.
To type sth up (phrasal verb) - to use a keyboard to make a printed copy of something that was written by hand.
To loathe (verb) - to hate someone or something.
To jot sth down (phrasal verb) - to write something quickly on a piece of paper so that you remember it.
Entry (noun) - a single written item in a list or collection of records.
Journal (noun) - a written record of what you have done each day, sometimes including your private thoughts and feelings
To unburden yourself - to free yourself of something that is worrying you, by talking about it to someone.
Tedious (adj.) - boring.
---
M: Do you write a lot?

R: Well, if you mean **extended** writing, then not a lot these days, I keep a diary, and, oh, I make notes for lessons. And occasionally I **file** reports. What else? Oh, well, I don't do it now, but I'd like to do more creative writing in the future as well.

M: Do you prefer writing by hand or typing?

R: Well, it depends what has to be written, I suppose. So simple notes for lessons can be **handwritten**, for example. But a report probably needs a more professional **typed-up** approach where you're sitting at your computer typing away and putting everything in a logical order and making it presentable.

M: Did you like writing things when you were a child?

R: Well, ironically, for someone who loves writing now, I absolutely **loathed** it when I was a child, actually. Unless it was creative writing. I used to love making up all the crazy plots and interesting characters and like sort of weird and wonderful settings. That was good fun. But if it was like writing for spelling practice, then I wasn't such a big fan.

M: What do you like to write?

R: Well, I really like writing lesson plans for myself if I can do it by hand. I like watching everything come together while I'm sort of **jotting down** the main stages and making small notes as I think about the students that I'm going to be teaching and adding in things that they like. I also like making **entries** in my **journal** as well. It's great to **unburden yourself** through writing, or at least I find it quite useful.

M: Do you think the things you write will change?

R: Well, I hope so. It would be a bit **tedious** if I wrote the same things all the time, wouldn't it? And of course, you have to go back and edit the things that you've written, especially if it's for an audience. The first draft is rarely the last one.