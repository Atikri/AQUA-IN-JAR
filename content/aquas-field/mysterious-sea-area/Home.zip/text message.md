How often do you send text messages? 
Do you reply to messages as soon as you receive them? 
Did you send more messages when you were younger? 
Is sending messages popular in your country?
---
- **Every now and then** – occasionally, not often. → I go to the cinema every now and then.
- **Handled** (verb) – managed or taken care of. → Most of the bookings are handled by our assistant.
- **Notifications** (noun) – alerts or messages from apps or systems. → I turned off all my notifications to focus on work.
- **Alerts** (noun) – warning or information messages, often from phones or computers. → The weather app sent an alert about the storm.
- **Bothered** (verb) – disturbed or interrupted. → I don’t like being bothered during meetings.
- **Emergency** (noun) – a serious or dangerous situation needing immediate action. → Call me only if it’s an emergency.
- **Alternatives** (noun) – other options or choices. → These days, people have many alternatives to traditional texting.
- **SMS** (noun) – Short Message Service; a basic text message sent via mobile phone. → I used to send SMS all the time before smartphones.
- **Near-constant** (adjective) – happening very frequently or almost continuously. → There is near-constant noise from the construction site.
- **Commonplace** (adjective) – very normal or usual. → Messaging friends online is commonplace now.