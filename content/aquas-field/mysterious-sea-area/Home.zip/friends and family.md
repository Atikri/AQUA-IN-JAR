## Vocabulary to talk about friendship and contacting old friends

1.  **bad at keeping in touch with:**  *not good at maintaining contact with someone* 
2.  **get back in touch:** *contact someone again*
3.  **have in common:** *share the same interests*
4.  **be into something:** *enthusiastic about something* 
5.  **hit it off right from the word go:** *become friends from the very beginning*
6.  **tell (you) straight to (your) face:** *express feelings and opinions directly to someone* 
7.  **in keeping with:** *according to the typical stereotype* 
8.  **go our separate ways:**  *take a different path in life*
9.  **far and few between:** *less and less frequent* 
10.  **be largely down to (me):** *mainly my fault or responsibility* 
11.  **come across by chance:** *find unintentionally*
12.  **it was she who tracked down his email:** *she investigated and found his email*
13.  **start out where (we) left off:** *continuing again from the last time we met* 
14.  **our friendship was as strong as ever:** *we were still as good friends as before* 
15.  **catch up and fill in the gaps:** *share details about what’s been happening in your life*

## Vocabulary to speak about family and friends

1.  **A lifelong friend** – A friend that you have had for most of your life
2.  **A relationship of trust** – a connection with another in which you have faith and confidence
3.  **Arrange a dinner date** – Plan to share an evening meal
4.  **A shoulder to cry on** – Someone to sympathize with you
5.  **Close-knit family** – A close family with common interests
6.  **Dear to my heart** – Someone that I care about
7.  **Distant cousins** – People who share a common ancestor but are not closely related
8.  **Extend the hand of friendship** – Reach out to someone in a friendly manner
9.  **Extended family** – Uncles, aunts and cousins form part of the extended family
10.  **Face to face** – In person
11.  **Get to know one another** – Learning different aspects of each other
12.  **Get together** – Meet up
13.  **Immediate family** – Spouse, parents, children, grandparents
14.  **Long lost friend** – A friend that you have lost contact with
15.  **Long-term relationships** – A committed relationship between partners
16.  **Nurture our friendships** – Looking after our relationships with friends
17.  **Professional relationships** – The relationships that we have in the workplace
18.  **Relationship problems** – Difficulties with people with whom we interact regularly
19.  **Share a common background** – The share a similar heritage or culture
20.  **Share the same ideas** – To have similar opinions and views
21.  **Stand the test of time** – To last a long time
22.  **Struck up a friendship** – To make friends
23.  **To enjoy someone’s company** – To enjoy spending time with someone
24.  **To have a good working relationship** – To work together well
25.  **To have a lot in common** – To have shared interests
26.  **To hit it off** – To like each other straight away
27.  **To keep in touch with** – To keep in contact
28.  **To lose touch with** – To lose contact

## **Vocabulary to talk about Toys**

1.  **go back a bit:**  *make you think of a time in the past* 
2.  **soft toys:**   *toys which look like animals made of cloth and filled with soft material* 
3.  **stand out in the memory:** *something important from your past you will always remember*
4.  **wrap (something) up:** *cover something like a gift in soft paper*
5.  **the look on (my) face:** *the expression on my face (of happiness or any other emotion)*
6.  **give (something away):** *show how you feel by your expression or behaviour*
7.  **lash out on (something):** *spend a lot of money on something* 
8.  **spoil (someone):**  *to be too indulgent to a child* 
9.  **set up:** *organise, put something together*
10.  **a learning tool:** *an object (a game, a platform) that can help you learn something*
11.  **educational toys:** *toys designed for learning*
12.  **stretch (your) imagination:** *make you think about things in a new way*
13.  **spend quality time:** *a very enjoyable time with someone, especially parents with children* 
14.  **let someone win:** *allow the other player to win* 
15.  **hand something down:** *pass on things from one generation of the family to the next*