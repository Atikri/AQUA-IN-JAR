## **Vocabulary to talk about cafés**

1.  **not look like much:** *the appearance is not very attractive*
2.  **the first thing that hits you is:** *the first impression or sensation you have*
3.  **be after something:** *want something* 
4.  **home-made:** *not commercially bought*
5.  **run something:** *in charge of or responsible for*
6.  **happen to pass by:** *be there by chance*
7.  **fancy a bite to eat:** *have the desire to eat something* 
8.  **give them all a miss:** *to avoid or say “no” to*
9.  **go for:** *to make a choice out of preference*
10.  **come back for more:** *return and ask for the same again* 
11.  **soak up the atmosphere:** *enjoy listening to people and looking at your surroundings*  
12.  **feel like a home from home:**  *a place where you feel welcome and comfortable*
13.  **hurry you up:** *make you finish quickly and leave*
14.  **put so much into the place:** *work very hard to make something successful*
15.  **find the time to pass the time of day with someone:** *make time to talk about everyday things*

## Food vocabulary

1.  **A balanced diet** – A diet of mostly healthy food that has the right amount of nutrients
2.  **A bottle of bubbly** – Sparkling wine
3.  **A decadent chocolate pudding** – Luxurious or self-indulgent chocolate pudding
4.  **A doggy bag** – The leftovers of a meal in a restaurant taken home
5.  **A scrumptious meal** – A delicious meal
6.  **A slap up meal** – an expensive or very indulgent ‘treat’ meal
7.  **A sweet tooth** – An enjoyment of sweet food
8.  **An English breakfast** – A large cooked breakfast that includes egg and bacon
9.  **Calm the hunger pangs** – To reduce the discomfort caused by hunger
10.  **Candle lit dinner** – A romantic dinner by candlelight
11.  **Covered in a rich sauce** – Covered in a creamy gravy
12.  **Cut down on** – To reduce consumption
13.  **Daily consumption** – The amount that you eat everyday
14.  **Dying of hunger** – Very hungry
15.  **Exotic meals** – Meals that originate in other countries
16.  **Fine dining** – Food catering to expensive tastes in a formal setting
17.  **Food preparation** – Preparing food
18.  **Food production** – Producing food
19.  **Fussy eater** – Someone dislikes many foods
20.  **Home-cooked meals** – Meals cooked at home
21.  **Homemade food** – Food made at home
22.  **Junk food** – Food with little nutritional value
23.  **Leafy vegetables** – Vegetables such as spinach and cabbage
24.  **Mouth-watering meals** – Delicious meals
25.  **Nutritious food** – Food with many nutrients
26.  **Quick snack** – a small meal that’s easy to eat ‘on the go’.
27.  **Packed with vitamins** – Full of vitamins
28.  **Piping hot cup of coffee** – Very hot coffee
29.  **Pub lunch** – Lunch served in a bar
30.  **Rabbit food** – Salad vegetables
31.  **Ready meals** – Heat and eat meals
32.  **Refined carbohydrates** – Foods such as white rice, white bread
33.  **Savouring the food** – Enjoying the food
34.  **Scrumptious meal** – An exceptionally tasty meal
35.  **Seasonal** **fruits** – Fruits that grow in season
36.  **Starving hungry** – Extremely hungry
37.  **Wining and dining** – Entertainment that includes good food