Do you like to take photographs? How do you keep your photos? Do you ever delete or throw away photos if they are on paper? Will you take more photos in the future, do you think?
---
Go out of your way - to try very hard to do something, especially for someone else.
Snap (noun) - an informal photograph that is not very skillful or artistic.
Ruin the flow - to kill the vibe/mood.
Scenic (adj.) - having or allowing you to see beautiful natural features.
Keepsake (noun) - something that helps you remember a person, place, or occasion.
Bulky (adj.) - too big and taking up too much space.
Theme (noun) - the main subject of a talk, book, film, etc..
Redundant (adj.) - more than what is usual or necessary, esp. using extra words that mean the same thing.