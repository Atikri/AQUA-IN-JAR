Two volunteers, Eleanor and Ben, are sorting through donated items in a cluttered storeroom at a local animal shelter. Eleanor, an older woman, is meticulously organizing a pile of blankets, while Ben, a younger man, is struggling to untangle a heap of dog leads.
---
E:Honestly, Ben, you're making a right pig's ear of that lot.
B:Tell me about it! These leads are in a proper tangle. Looks like a Gordian knot, this does.
E:Here, let me have a go. You'll be there all day otherwise.
B:Cheers, Eleanor. I'm all fingers and thumbs today.
E:Right then. Now, where's my trusty bodkin? That'll sort it.
B:A bodkin? Bit old school, isn't it?
E:Needs must, dear. Needs must.
B:Fair enough. I'll go and see if they need any help down at the kennels then.
E:Good lad. They're always short-staffed on a Saturday.
B:Right you are,...