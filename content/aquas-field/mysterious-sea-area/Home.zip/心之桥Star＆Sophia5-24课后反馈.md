到校时间：17：15

情况反馈：作业完成情况整体良好，作业开放题问why时，注意because的拼写，一定要记住！对新学的课文和单词掌握情况也很好。:smiley: 


注意三单的否定式表达
Don't 和 Doesn't 的用法

注意黑板列出来的单词，需要加强记忆！皆为之前单元的一些单词。很多单词会发音但是拼写普遍有问题。
- movie theater
- department store
- apartment
- cucumber
- problem
![IMG_20250524_202422.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/759a95c8-356a-422e-bc73-82f5649db25f--IMG_20250524_202422.jpg)