**Examiner: What type of holiday destination do you think attracts most tourists?**

*Answer: I know that many people are drawn to* ***wildlife safaris****. This is certainly one of the big attractions in Africa. In Europe and Asia, the* ***stunning architecture****, museums and* ***arts and culture*** *attract thousands of tourists every year.*

**Examiner: Do you think that the tourism industry will continue to grow in the next two decades?**

*Answer: I do. Many European and Asian countries have aging populations who will have* ***time on their hands*** *in the future. Many of them are likely to seek* ***holiday destinations around the world****. Today there are many* ***affordable destinations*** *that offer* ***good value for money.***

**Examiner: What do you think your country could do to attract more tourists?**

*Answer: My country has stringent* ***visa regulations****. If these were relaxed, I think that more visitors would choose to visit. We have an* ***efficient public transport****, plenty of accommodation and natural and historical places of interest.*