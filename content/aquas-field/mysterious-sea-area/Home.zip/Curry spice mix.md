## Ingredients:
- 15 cardamom pods
- 10 cloves
- 1 tbsp coriander seeds
- 1 tbsp cumin seeds
- 1 tbsp fenugreek
- 1 tsp caraway seeds
- 1/2 tsp mustard seeds
- 1 tbsp ground cinnamon
- 1 tsp black pepper
- 1 tsp ground ginger
- 1/2 tsp cayenne pepper

---
## Steps:
1. In a mortar and pestle or spice grinder, grind the cardamon pods, cloves, coriander seeds, cumin seeds, fenugreek, caraway seeds and mustard seeds until the spices become a powder. Transfer to a dry mixing bowl.
2. Add the turmeric, cinnamon, black pepper, ginger and cayenne pepper and combine well.
3. Once combined, transfer to a dry, airtight container. it keeps out of the fridge for up to 3 months.
