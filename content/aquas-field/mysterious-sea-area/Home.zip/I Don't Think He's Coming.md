I Don't Think He's Coming (One Take Live Recording Version)
曲：藍奕邦
詞：藍奕邦
編：藍奕邦 / 李漢金
監：藍奕邦 / 李漢金
I don't think/ that he's coming to town /tonight
I don't think/ you should wait~ for him on this mountain top
I know you/ have been waiting for him/ for quite a while
（But） you're having too much fun to /wave this world goodbye
l guess
I don't think/ he has something to give us now
I don't think/ he would like to see this place he made
And he says clean up this/ crap and I'll think about coming
But I said/ come clean it up yourself
As if we really/ need your help
I know he sees me
I know he feels me
I know he's up there
Somewhere among those stars and the pilot lights
I know he feels me
I know he wants me
I know he loves me
But I just don't think that he's coming to town tonight
Is he still/ on the phone with the Vatican Man?
Maybe he/ missed the bus and decide not to come~
Maybe he just don't wanna wreck this party
And he knows that we will do just fine
（We） just have to see him/ in our minds
I know he sees me
I know he feels me
I know he's up there
Somewhere among those stars and the pilot lights
I know he feels me
(+who ) I know he wants me
I know he loves me ，baby
But I just don't think that he's coming to town tonight
And he knows that we will do just fine, just fine
he knows that we will do just (+la) fine
he knows that we will do just fine
And he knows that we will do just fine
(We) just have to see him in our minds
I know he sees me
I know he feels me
I know he's up there ,yes
Somewhere among those stars and the pilot lights
I know he feels me
I know he wants me ,oh
I know he↓ loves me
But I just don't think that he's coming to town tonight
