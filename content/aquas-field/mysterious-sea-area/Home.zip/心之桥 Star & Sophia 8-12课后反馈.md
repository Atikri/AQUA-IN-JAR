- 上课内容：复习上节课单词以及was/were的语法点。学习新的单词，以及语法运用的句子，进行句子的读写练习。:maple_leaf: 
- 单词拼写方面仍然容易出错，注意student拼写。:fallen_leaf: 
- 注意判断过去式的关键词，yesterday为昨天的意思。
![IMG_20250812_155853.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/4ae7e9c0-1c26-4694-9b0a-69a0581a2db8--IMG_20250812_155853.jpg)

---
![IMG_20250812_155914.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/3884002a-ed87-44d3-8a82-195982a62168--IMG_20250812_155914.jpg)