Part 2总是说不满时长，不知道怎么加细节。
讲得乱七八糟，没有逻辑，像在碎碎念。
如何用STAR法来解决这两个痛点？

01 什么是STAR法？
STAR法原本是用来回答行为面试问题的，但在雅思口语中同样适用。
它的四个步骤如下：
S - Situation（情境）👉引出背景，说明事情发生的时间、地点、人物
万能框架：I remember a time when…（我记得有一次……）A few months ago / Last year, I experienced…（几个月前 / 去年，我经历了一件……）This happened when I was…（这件事发生在我……的时候）One day, my [relative/friend/colleague] needed help with…（有一天，我的[亲戚/朋友/同事]需要帮助……）At that time, I was…（当时，我正在……）
高分表达：Out of the blue, I got a call from…（突然，我接到了……的电话）It was an ordinary day until…（那天本来很普通，直到……）Little did I know that this small favor would make such a big difference.（我当时完全没想到，这个小小的帮助竟然会产生这么大的影响。）

T - Task（任务）👉描述你的目标或需要完成的事情
万能框架：My task was to…（我的任务是……）I had to figure out how to…（我需要想办法……）They needed me to…（他们需要我……）I was responsible for…（我负责……）It was important for me to…（对我来说，重要的是……）
高分表达：The challenge was that…（挑战在于……）It seemed simple at first, but…（一开始看起来很简单，但……）I was a bit hesitant at first because…（一开始我有点犹豫，因为……）

A - Action（行动）👉详细描述你采取的步骤和具体行动
万能框架：First, I…（首先，我……）Then, I decided to…（然后，我决定……）To make things easier, I…（为了让事情更简单，我……）At first, it didn’t go smoothly because…（一开始并不顺利，因为……）To solve this problem, I…（为了解决这个问题，我……）
高分表达：I walked them through the process step by step.（我一步步地教他们。）I patiently explained everything, making sure they understood.（我耐心地解释每一个细节，确保他们理解。）After a few attempts, they finally got the hang of it.（试了几次之后，他们终于掌握了技巧。）I went the extra mile by…（我额外做了……）

R - Result（结果）👉说明你的行动带来了什么影响或变化
万能框架：As a result,…（结果是……）In the end, they were able to…（最后，他们成功地……）After that, they felt more confident about…（之后，他们对……更有信心了。）I was really happy to see that…（我很高兴看到……）Looking back, I realize that…（回头看看，我意识到……）
高分表达：This experience not only helped them, but also taught me a valuable lesson.（这次经历不仅帮助了他们，也让我学到了宝贵的一课。）Since then, they’ve never had trouble with it again.（从那以后，他们再也没有遇到过这个问题。）It was incredibly rewarding to see them so grateful.（看到他们如此感激，我感到非常有成就感。）This small act of kindness strengthened our bond.（这次小小的善举加深了我们的关系。）

02 适用话题示例
帮助他人S：几个月前，我奶奶刚换了新手机，不会用。T：我需要教她如何打电话和用微信。A：我写下操作步骤，手把手教她，还调整了手机设置。R：她现在每天都能自己用手机，还会给我发语音消息。
S - Situation（情境）I remember a time when my grandmother got a new smartphone a few months ago. She had never used a touchscreen device before, so she struggled to make phone calls and send messages. At that time, she relied on a traditional keypad phone, and switching to a smartphone was quite overwhelming for her.
T - Task（任务）My task was to teach her how to use the basic functions of the phone, especially making calls and using WeChat, which is essential for keeping in touch with family. Since she wasn’t familiar with touchscreens, I had to make sure my explanations were clear and easy to follow.
A - Action（行动）At first, I explained the basics and showed her how to unlock the phone and navigate the home screen. Then, I wrote down simple step-by-step instructions in a notebook so she could refer to them later. To make things easier, I increased the font size and adjusted the settings so that everything was more visible for her. I also demonstrated how to make a phone call and send voice messages on WeChat. I patiently walked her through the process several times until she got the hang of it.
R - Result（结果）As a result, she was able to use her smartphone independently. Now, she sends me voice messages almost every day and even makes video calls with my relatives. Seeing her so excited and confident about using technology made me feel really happy. Looking back, I realize that this small effort not only helped her but also strengthened our bond.
