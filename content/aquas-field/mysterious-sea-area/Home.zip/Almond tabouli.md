anything's possible P138
Serves: 1-2
---

## Ingredients:
 * 1/2 cup raw almonds
 * 1•1/2 cup parsley (70g), finely chopped
 * 1 cup cherry tomatoes (150g), diced
 * 1 lemon, to make 2 tbsp of juice and 1 tsp of zest
 * 1 tsp sumac
 * 1/2 tsp salt
 * 1/2 tsp pepper

---


## Introduction:
We love growing fresh herbs. We have them in little pots just outside our kitchen so it's easy to add extra flavour to food. When parsley is in abundance, we make tabouli. It's super simple, shows off the produce and, in turn, celebrates nature in all its beauty.

---


## Instructions:
 * Chop the almonds in a mortar and pestle, making sure you don't turn them into almond meal. You want them to retain a crunch and give the dish texture.
 * Place a fry pan on a high heat and toast the almonds until brown. Set aside to cool.
 * Once the toasted almonds are cool, add all ingredients to a medium mixing bowl. Combine and serve straightaway. A great side to Mum's nut rissoles (p.98) or on top of a slice of pumpkin, brown rice and seed loaf (p.62).
