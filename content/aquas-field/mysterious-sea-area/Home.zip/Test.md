```mermaid
xychart-beta
    title "Sales Revenue"
    x-axis [jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec]
    y-axis "Revenue (in $)" 4000 --> 11000
    bar [5000, 6000, 7500, 8200, 9500, 10500, 11000, 10200, 9200, 8500, 7000, 6000]
    line [5000, 6000, 7500, 8200, 9500, 10500, 11000, 10200, 9200, 8500, 7000, 6000]
    
```
```mermaid
graph TD
    A[Enter Chart Definition] --> B(Preview)
    B --> C{decide}
    C --> D[Keep]
    C --> E[Edit Definition]
    E --> B
    D --> F[Save Image and Code]
    F --> B
```
```mermaid
graph TD
    %% 贾府主要成员
    贾演 --> 贾代化
    贾代化 --> 贾敬
    贾敬 --> 贾珍
    贾珍 --> 贾蓉
    贾代化 --> 贾敷
    贾敷 --> 贾蔷

    贾源 --> 贾代善
    贾代善 --> 贾赦
    贾赦 --> 贾琏
    贾琏 --> 贾巧姐
    贾代善 --> 贾政
    贾政 --> 贾珠
    贾珠 --> 贾兰
    贾政 --> 贾元春
    贾政 --> 贾宝玉
    贾政 --> 贾探春
    贾政 --> 贾环
    贾代善 --> 贾敏
    贾敏 --> 林黛玉

    %% 王夫人与贾政
    王夫人 --> 贾珠
    王夫人 --> 贾元春
    王夫人 --> 贾宝玉

    %% 贾宝玉与其他人物
    贾宝玉 --> 林黛玉
    贾宝玉 --> 薛宝钗
    贾宝玉 --> 史湘云
    贾宝玉 --> 袭人
    贾宝玉 --> 晴雯

    %% 薛家
    薛姨妈 --> 薛蟠
    薛姨妈 --> 薛宝钗

    %% 其他关系
    贾珍 --> 秦可卿
    贾蓉 --> 秦可卿
    贾琏 --> 王熙凤
    王熙凤 --> 贾巧姐
    贾母 --> 贾宝玉
    贾母 --> 林黛玉

    %% 标注
    classDef 男性 fill:#99ccff,stroke:#333,stroke-width:2px;
    classDef 女性 fill:#ffcc99,stroke:#333,stroke-width:2px;

    class 贾演,贾代化,贾敬,贾珍,贾蓉,贾敷,贾蔷,贾源,贾代善,贾赦,贾琏,贾政,贾珠,贾兰,贾宝玉,贾环,薛蟠 男性;
    class 贾元春,贾探春,贾敏,林黛玉,王夫人,薛姨妈,薛宝钗,秦可卿,王熙凤,贾巧姐,贾母,史湘云,袭人,晴雯 女性;
```

```mermaid
pie title Pets adopted by volunteers
    "Dogs" : 386
    "Cats" : 85
    "Rats" : 15
```