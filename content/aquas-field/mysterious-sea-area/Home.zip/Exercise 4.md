# Demonstrate
TVFs: Onset/Offset 

- [ ] 1.  Glottal: closure precedes/ends airflow;
- [ ] 2.  Aspirate Abrupt: abrupt movement in/out of airflow;
- [ ] 3.  Aspirate Gradual: gradual movement in/out of airflow;
- [ ] 4.  Smooth: movement and airflow coordinated simultaneously.

---
**Advanced Practice:** 

Perform these tasks on / i, e, a, o, u / at any pitch;

Practice moving between conditions abruptly, gradually;

Practice with different True Vocal Fold Body-Cover conditions.