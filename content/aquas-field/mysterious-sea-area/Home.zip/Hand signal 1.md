1. [High](https://my.supernotes.app/?preview=baf9e2e2-1103-4f69-926d-26bdae1c0f66)
2. [Mid](https://my.supernotes.app/?preview=140d5e13-09d4-46ea-88d6-7f6cfae815c4)
3. [Low](https://my.supernotes.app/?preview=ba40f018-f2a3-4a14-84f3-56786453dca8)
4. [Compressed](https://my.supernotes.app/?preview=6cfe4576-3807-4031-b610-799fa2156323)