The IELTS writing exam is split into two parts and task 2 is worth 66% of your score.

The IELTS writing task 2 is an essay writing task that assesses your ability to express and develop an argument in response to a given topic.

You are allocated 40 minutes to write it.

On the official British Council site there are documents that state your essay must contain at least 250 words, however, in the official criteria, there is no mention of 250 words.

The basic structure for IELTS writing task 2 in the IELTS exam is as follows:

Introduction: Be sure to state the question in your own words in your introduction so that you introduce the topic of your task 2. Task 2 statements are often a [paraphrasing](https://my.supernotes.app/?preview=403985df-ec55-4bd9-898e-e0d87cdb7e41) of the initial question.
Support your opinion: Once you have made your opinion clear, you have to provide facts to justify your choice
State the opposing point of you. You do not have to persuade the examiner about the opposing opinion, but it is important to state what it is. 
Summarise your opinion.