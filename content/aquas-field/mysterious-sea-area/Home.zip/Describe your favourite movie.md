# You should say:

- when and where you saw it
- what type of film it was
- what the film was about
- explain why it is your favourite film

# Sample Answer
Oh…this is such a difficult topic. There are so many great films I’ve seen and to choose one as my favourite is just impossible. 

But that’s what I’ve been asked to talk about so the film I’ve gone for is Forest Gump not only because I think it’s a great film but also it’s one I guess most people have seen so I won’t appear to be some kind of film buff that’s talking about an Art House movie nobody’s ever heard of.  And Forest Gump won around six Oscars, including Best Picture so, if that’s anything to go by, then it must be pretty good!

I must have seen it around three or four times. I never saw it when it was first released in 1994. I was a bit too young at the time, just a year old but I saw it first on TV when I was around 12 or 13, watching it with my elder brother who kept on trying to explain to me what it was all about. And since then, I recall watching it at least twice on streaming services. 

One of the things I most like about the film is that it is not easy to put a label on it. In a sense it’s whatever you want it to be. On one level, it’s a romantic comedy, a love story. At the same time, it’s a fantasy, what some people call “magic realism” because it mixes fantasy with real events. Or is it a kind of political drama or satire even, a critical look at the history of the United States from the 1960s through to the early 1980s?

It tells the story of Forest Gump from his childhood onwards and the love between him and his mother as well as his love for a girl, Jenny, he meets at school. Forest appears to be slow-witted, completely innocent but over the years accomplishes so much, winning medals for bravery in battle, becoming a top table tennis player, setting up a shrimp fishing business and making a million out of it, as well as meeting several US Presidents including JF Kennedy. Meanwhile, Jenny leads a different life, ending up with drug and alcohol issues. At the end though, they finally get married and have a year of happiness before she dies, leaving him with their young son. 

There are those who have criticized the film for having as its hero a man who has no thoughts on anything, except for an unbounded optimism, who becomes successful at whatever he does without any conscious effort. I understand that view and see it as another layer of meaning the story has. That’s what makes it such a great film. There’s something in it for everybody. It can make you laugh, cry, feel for the characters and get annoyed with them all at once. In other words, the film is open to interpretation and you can get a lot out of it in all kinds of ways. And the acting of course, especially with Tom Hanks in the lead, is first class. I know he has starred in many films but I believe this is his best.