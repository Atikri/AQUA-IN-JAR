> Alistair, a retired history professor, and Brenda, a local artist, find themselves sheltering from a sudden downpour under the awning of a quirky antique shop in a small Cotswolds village. They've never met before, but the shared predicament sparks a conversation.

**Alistair**: Well, isn't this a bit of a how's your father?
**Brenda**: Tell me about it. I was just admiring that rather ghastly porcelain cat in the window.
**Alistair**: Ghastly is putting it mildly. Looks like something my late Aunt Mildred would have adored. She had questionable taste, ==bless her==.
**Brenda**: I expect it's ==frightfully== expensive, then. Anything that hideous usually is.
**Alistair**: Probably. Still, at least it's given us a bit of shelter, eh?
**Brenda**: True enough. I'm Brenda, by the way.
**Alistair**: Alistair. Pleased to meet you. So, are you local?
**Brenda**: ==Born and bred==, I'm afraid. Though I do try to escape when I can. You?
**Alistair**: Relatively new to the village, myself. Retired here a couple of years back. Needed a bit of peace and quiet after all those years teaching history at Oxford.
**Brenda**: Oxford, eh? ==Fancy that==. I'm just a humble artist, knocking out landscapes for the tourists.
**Alistair**: Don't be ==daft==, I'm sure they're rather good.