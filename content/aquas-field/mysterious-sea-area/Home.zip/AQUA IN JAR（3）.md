Guest:
> Eric

Date:
> 2025.6.30

Songs:
> love yourself
> 梦灯笼
> lemon
> ---
> Aquarius 
> White lies
> 13楼的大笨象
> Shattered
> 7月24日大道
> 小夜灯
> First love
> 迷魂记
> 刹那的乌托邦
---
![IMG_20250630_212134.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/d872815f-f97f-4a73-be45-ffe791d489e0--IMG_20250630_212134.jpg)