**Maria: Do you like making plans?**  
Rory: Yeah, I love a plan. Maybe not the execution so much, but I like organising everything and putting it in place, so well, everything is ready. It makes me feel safe knowing everything has been accounted for.  
 --- 
**Maria: Do you always make plans?**  
Rory: I try to, yeah. Sometimes it's fun to have a random day trip or something like that. But for the most part, I like to know what I'm doing and when, since I'm a very orderly person.  
  ---
**Maria: And what do you usually plan?**  
Rory: Oh, I think I have a plan for everything. I plan my day so that it goes as productively as possible. And I plan my lessons so they're effective and efficient. And I like making plans for my finances and things like that. So I always have money to do what I want to do.  
  ---
**Maria: What are the benefits of making plans?**  
Rory: I mean, well, they're pretty much endless. Financially speaking, if you have a plan, then you can use your money effectively than just spending it on the go or as it comes in. Then there's the almost psychological security of having everything in order. I think those are the two that stand out the most for me when I'm putting plans together.