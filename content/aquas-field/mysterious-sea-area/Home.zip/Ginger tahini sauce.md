
1. Blend all of the ingredients in a high-speed blender until smooth. Add more water if it is too thick and you would like a thinner sauce.
2. Keep in the fridge for up to 5 days. It will become thicker once cold.
   Serve with a sprinkle of black pepper.

---

½ cup tahini

½ cup filtered water

2 tbsp tamari

1 tbsp apple cider vinegar

1 tbsp maple syrup

1 tsp garlic, minced

1 tsp fresh ginger, grated with skin on

1 tsp fresh turmeric, grated with skin on or

½ tsp ground turmeric

½ tsp pepper

---

To serve

pinch of black pepper

---

62