# You need 3 daily wins:
## A physical win.

- Walking, running, lifting, swimming..

## A mental win.
- Reading, writing, creating, learning..

## A spiritual win.
- Praying, meditating, studying, growing..

Be a complete winner!

---

![mmexport1757408564188.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/5f7f7dcf-85dc-4d13-afdf-39ef9f3cb359--mmexport1757408564188.jpg)
