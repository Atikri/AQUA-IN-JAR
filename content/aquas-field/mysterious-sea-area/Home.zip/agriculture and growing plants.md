Do you think it's good to let children learn how to plant?
Are there many people growing their own vegetables now?