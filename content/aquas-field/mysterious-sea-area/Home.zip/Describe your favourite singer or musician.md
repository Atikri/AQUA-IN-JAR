## Describe your favourite singer or musician.

**You should say:**

- who this singer/musician is
- what type of songs/music he/she sings/composes
- what type of people listen to his / her songs/music

**and explain why he/she is your favourite singer/musician.**