
---
- [ ] 【5个原始动作可解决95%的问题-哔哩哔哩】 https://b23.tv/vhn1tE2
- [ ] 【改善圆肩驼背一次见效 练完巨显高！！！15min椅子芭蕾 背部激活-哔哩哔哩】 https://b23.tv/HfOxe4p
- [ ] 【16分钟背部普拉提，紧致后背，改善圆肩驼背，美化背部线条-哔哩哔哩】 https://b23.tv/0CvBRXB
- [ ] [Learning how to Read, again - by Jovana - Highbrow & Lowkey](https://substack.com/home/post/p-158759958)
---
complementary 互补的（complement）
intriguing /ɪnˈtri:gɪŋ/ 引起好奇心的;令人感興趣的;有迷惑力的（**It’s one of those intriguing but often kind of nebulous terms.**）
guardrail （There are literally no guardrails in place.）
endow /ɪnˈdaʊ/ 捐贈；天生具有；賦予（Most of what we see in AI today is really machine learning: **endowing** computer systems with the ability to learn from examples.）
nuance /ˈnjuːɑːns/ （外表、意義、聲音等的）細微差別 （The more data involved in training the language model, the more **nuanced** it becomes）

---
浪费生命的APP
當我覺得人生卡住的時候，我通常第一個會做的事情是去看 Seth Godin 的部落格。到 [https://seths.blog](https://seths.blog) 輸入你[可能會有興趣的關鍵字](https://seths.blog/?s=jobs)，也許他已經寫過你的問題了。

他的很多書我都覺得對我幫助很大，如果是第一次接觸 Seth Godin 的話，也許可以從《[Linchpin: Are You Indispensable?](https://www.amazon.com/Linchpin-Are-Indispensable-Seth-Godin/dp/1591844096)》開始；記得請買英文版，因為中文版翻譯得不太好。
而且現在有相當多管道可以取得[無 DRM 限制](https://wiwi.blog/blog/drm-doesnt-work)的音樂檔案：你可以購買實體專輯然後轉檔，或是到 iTunes Store、[Bandcamp](https://bandcamp.com/) 或創作者的個人網站，甚至是使用 [yt-dlp](https://github.com/yt-dlp/yt-dlp) 這類工具都可以。
