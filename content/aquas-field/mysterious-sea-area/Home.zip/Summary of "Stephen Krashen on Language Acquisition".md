Stephen Krashen’s work on language acquisition is centered around five key hypotheses:

1. Acquisition-Learning Hypothesis

Language acquisition is subconscious, similar to how children acquire their first language.

Language learning is a conscious process involving grammar rules and formal instruction.

Acquisition is more effective for real communication.

2. Monitor Hypothesis

The "monitor" is a mental editor that applies learned grammar rules before speaking or writing.

Over-reliance on the monitor can hinder fluency.

Effective use requires knowing the rules, having time to apply them, and focusing on correctness.

3. Natural Order Hypothesis

Language structures are acquired in a predictable order, independent of direct teaching.

Some structures appear early, while others take longer.

Instruction does not change this natural order.

4. Input Hypothesis (i+1 Theory)

Comprehensible input is essential—learners acquire language when exposed to slightly more advanced material than their current level.

Input should be meaningful and understandable (not just grammatical drills).

Listening and reading play a crucial role in this process.

5. Affective Filter Hypothesis

Emotional factors (motivation, anxiety, self-confidence) influence language acquisition.

A high affective filter (stress, fear) blocks input from being effectively processed.

A relaxed and encouraging environment improves learning outcomes.





```mermaid
graph TD
    A["Language Acquisition"] --> B["Acquisition-Learning Hypothesis"]
    A --> C["Learning (Grammar, Rules)"]
    C --> D["Monitor Hypothesis"]
    B --> E["Natural Order Hypothesis"]
    E --> F["Input Hypothesis"]
    F --> G["i+1 Learning"]
    G --> H["Affective Filter Hypothesis"]
    H --> J["Motivation, Anxiety, Self-confidence"]
    J --> A
````