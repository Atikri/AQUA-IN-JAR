What’s your morning routine? 
How is your morning routine different from when you were a child? 
What would you like to change about your current routine?
What’s a typical morning routine like for people in your country?
---
A sense of accomplishment/achievement (phrase) — to feel/have a sense of accomplishment/achievement means to feel like you’ve achieved your goal or accomplished something important.
To go through the motion (idiom) -to do something without having much interest in it.
For starters (phrase) — as the beginning or first stage of something.
Extensively (adv.) — to a large or detailed degree.
Of one’s own accord (idiom) — If you do something of your own accord, you do it because you want to, without being asked or forced.
A great deal (phrase) — a large amount or quantity of something.
To put sth into sth/doing sth (phrase) — If you put time, work, or effort into something, you spend a lot of time or effort doing it.
Under normal circumstances (phrase) — normally, usually.
---
## Maria: Rory, so let’s talk about your morning routine, shall we? What’s your morning routine?

Rory: Oh, I love my morning routine. It’s always the same and it gives me **a sense of accomplishment** **going through the motions** of it. I get up, make my bed, switch on my laptop and usually do a limited amount of work while I’m working out and that usually lasts for an hour or so before I finish up and go for a shower, do my hair, make breakfast, and then I get back to work for the rest of the day.

## Maria: How is your morning routine different from when you were a child?

Rory: Well, I suppose my parents are a lot less involved with it, **for starters**. I don’t live with them anymore. I also used to rely quite **extensively** on an alarm clock. I always used to have to set multiple alarm clocks. But now, I wake up **of my own accord**, really. Of course, I have the alarm still as a backup, but I don’t seem to need it. And the last thing, I suppose, in terms of differences is that it’s more active now. I was more of a sloth in the morning than I am now. Usually I wake up full of energy these days.

## Maria: What would you like to change about your current routine?

Rory: I don’t know. I suppose not **a great deal**, although it would be really good if I could take a pill or something, that means I have to work out less in the morning because it takes forever. But I don’t mind **putting in the effort** really when I think about it. Other than that, it might be nicer to wake up a little bit earlier and get more done. But to be honest with you, my level of productivity is very good. So I’d only make some small changes and not major ones.

## Maria: What’s a typical morning routine like for people in your country?

Rory: Well, I imagine it’s different these days due to the quarantine, but **under normal** circumstances in Russia, I think people usually wake up earlier than I do, since they need to use the Metro to get to work on time and it can get very crowded. It’s not that essential for me. Even before the quarantine, to be honest, in Scotland, I think most people wake up around about half past seven to eight o’clock in the morning, have breakfast, shower, get dressed and then head off to work or school. It’s simple, but easy to follow, especially if you’re sleepy in the mornings.