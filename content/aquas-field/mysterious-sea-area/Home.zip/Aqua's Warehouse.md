# Reference Resource:
---
# Warehouse:
[To Be Transported](https://my.supernotes.app/?preview=c2519bc0-2ea6-440c-a18c-a77247100ea6)
Wares
[AQUA](https://my.supernotes.app/?preview=44a250d6-9de8-4b3b-a76c-9116337651d7)
to be