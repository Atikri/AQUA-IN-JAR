Migration is a complex issue, and biologists define it differently, depending in part on what sorts of animals they study.

本句是一个由and连接的并列句。前一个分句的主干是Migration is a... issue，后一个分句的主干是biologists define it。现在分词短语depending in part on what sorts of animals they study作伴随状语，其中what引导宾语从句，作depending on的宾语；they study是省略that的定语从句，修饰animals。
---
migration /maɪˈɡreɪʃn/
n. 迁徙，移居；迁徙
【搭配】
migration patterns 迁徙方式
language migration 语言迁徙
【同根】migrate vi. 迁移
---
issue /ˈɪʃuː/

v. 流出；发行；n. 发行（物）；问题

【搭配】issue a statement 发表声明

issue shares 发行股票

at issue 讨论或争议中的

environmental issues 环境问题
---
biologist /baɪˈɒlədʒɪst/

n. 生物学家
【记忆】词根记忆：bio（生命）+logist（…学家）→生物学家

【同根】biology n. 生物学

biological adj. 生物的，生物学的

microbiology n. 微生物学
---
define /dɪˈfaɪn/

v. 下定义；限定；解释

【搭配】define sth. as 把某物解释/定义为

【同根】definition n. 定义
---
in part
部分地
---
sort /sɔrt/
n. 种，类；类型
【搭配】all sorts of 各种各类的