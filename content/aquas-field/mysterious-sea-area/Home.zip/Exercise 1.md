## MY AQUA:
Whatever the length of time, just get some exercise in.:mountain_biking_woman:
I found that if I have no motivation , just standing up and doing some exercise makes me more active!

## MY THOUGHTS:
