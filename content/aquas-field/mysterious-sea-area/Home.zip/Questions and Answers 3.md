**Maria: Are there many street markets in your country?**  
Rory: Um, yeah, there are a few village markets that ==get put on== from time to time, and occasionally they bring their *wares* to the city centres as well.  
  
**Maria: When was the last time you went to a street market?**  
Rory: Um, that's a good question. I think it was when I was abroad, actually. There were rows of ==stalls== ==flogging== all kinds of things from jewellery to ==stationery==. It was very interesting to see, actually. We don't see so many stationery stalls at street markets in my country.  
  
**Maria: Do you prefer shopping in a shopping mall or at the street market?**  
Rory: Well, I like to ==get everything in one go==, so shopping malls ==cater to== this nicely, unless I'm shopping for something special like a souvenir. Then I head down to the markets.

**Maria: What do you usually buy at a street market?**  
Rory: Um, whatever catches my eye, really. Like I said, it's usually something that signifies a particular place or something for a specific person, so there's quite a range. One of the last things I picked up was a candle holder, actually, but before that, it was a necklace. So, like I say, there's quite a lot of diversity in the things that I can buy from a street market.