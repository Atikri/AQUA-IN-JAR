Maria: How often do you send text messages?  
>Rory: Only every now and then these days. Most of my messaging is handled by apps. Unless you count using those as texting, in which case I'm doing it all the time.  
---
Maria: Do you reply to messages as soon as you receive them?  
>Rory: Well, actually, I have all my notifications and alerts turned off. So I'm not bothered by things like that when I'm working, or in general, really. I usually just answer them when I can. If it's an actual emergency, then people can always call me and I will definitely see that.  
  ---
Maria: Did you send more messages when you were younger?  
>Rory: Absolutely! But there were fewer alternatives back then. We used to just send something like an SMS on our phones and that was it. It's different now with smartphones and near-constant internet connections. You can be messaging all the time.  
  ---
Maria: Is sending messages popular in your country?  
>Rory: Via text? Maybe if you're an old person or someone without a smartphone, but that's a rarity in my experience. Most people just message on their smartphones using different apps, like WhatsApp, for example. Unless, again, we are counting using those to message as texting, but then if we are, that's pretty commonplace.