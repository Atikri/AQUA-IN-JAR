**Maria: What kind of apps do you spend money on?**  
Rory: Well, none of them. I think I pay an annual or monthly subscription fee for some banking apps I use, but that's negligible. For the rest, they're all free, and rightly so. I don't see why I should have to pay for apps that are riddled with adverts.  
  
**Maria: What apps don't you use anymore?**  
Rory: I think I stopped using a few financial ones after I closed my account. And I don't think I'd be caught dead using one of the gaming ones. They seem like a complete waste of time.  
  
**Maria: What applications do you still use?**  
Rory: Oh, wow. Well, it would be easier to say what I don't use, to be honest. I use a whole load for social media and social networking, and then they're the ones that manage my calendar as well, so I don't forget things. Not only is it about my social life, though. My work's also on there. I use different apps to publish things from time to time, like on Instagram. And before I put them out there, I create them on an app called Canva as well.  
  
**Maria: What kind of apps have you downloaded on your phone?**  
Rory: Recently? Nothing very exciting. I had to get hold of a taxi app the other day because it was impossible to just flag one down in the city centre. But aside from that, I usually stick to the ones I've had for years. Not very interesting.