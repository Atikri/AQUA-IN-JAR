「我這輩子遇到的來自各行各業的聰明人，沒有一個不每天閱讀的——沒有，一個都沒有。」——查理·蒙格
---
消費資訊不等於獲得知識，任何想法都不可能遠離事實。
---
“Every time I read a great book I felt I was reading a kind of map, a treasure map, and the treasure I was being directed to was in actual fact myself. But each map was incomplete, and I would only locate the treasure if I read all the books, and so the process of finding my best self was an endless quest. And books themselves seemed to reflect this idea. Which is why the plot of every book ever can be boiled down to ‘someone is looking for something.’” —Matt Haig, Reasons to Stay Alive