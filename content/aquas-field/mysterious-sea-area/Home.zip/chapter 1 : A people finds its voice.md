针对第一节内容a people finds its voice，做一个概要讲解，并且可以提供未来研究主要方向。还可以具体结合实践，有哪些内容是我们可以立马进行实操进行的。这几个方面交织融合讲解，可以具体一点
---
• **最深層次的訊息：** 原始的聲音具有生理起源，但後來被借用來產生有意義的聲音，最終成為一種不僅是溝通，更是**個體身份的工具**。無論傳達何種訊息，最重要的是傳達的是「自我」。聲音是將自我「親密而有力地實現」的媒介。
> - the voice did not emerge “opera-ready.” the amazing performance Tanya witnessed was many centuries in the making. the primitive voice had its physiological inception as an assortment of attributes developed to enhance purely biological functions and then borrowed to produce meaningful sound. You can follow the voice’s evolution into an instrument not only of communication but also of individual identity and, ultimately, the sustainer of values we all hold dear.
> - That identity, your matchless self, is intimately and powerfully realized in your voice. Self-affirmation is embedded in your every utterance. When you think of the sound you make, you think of your voice. When others think of the sound you make, it is likewise your voice they bring to mind.
> - Your self is realized most powerfully in your voice. 
> - The employment of presentation skills presupposes that you have in mind a way you would like to be viewed. There is nothing intrinsically deceptive about using presentation skills, as long as you use them ==to display and not mask who you are.==

• **藝術作為表達的工具：** 偉大的演講者會結合**面部、手勢和聲音**來傳達精心設計的訊息。表演教練強調，溝通是讓別人「看到你所見」，而優秀的演講者或演員會「擁有舞台」，將他們的緊迫感推向聽眾。
> Mixing and balancing pitch and intensity, a speaker changes inflection and intonation. Talented speakers use this vocal variety to add interest, emphasis, and, ultimately, ==meaning to what they are saying==.
> - Powerful presenters know how to utilize every asset to best advantage. They ==combine face, gesture, and voice== to deliver a well-crafted message in the most effective manner. They achieve their goal: ==to give information, to persuade, to build relationships, to affirm themselves, or to evoke an emotion.==
> - “When your body is always pulling you upward and when your voice is strong enough to fill the room, you’ll be worthy of standing on the stage, communication.” He continued, “is making someone else see what you see.” It is grabbing hold of the picture in your mind and ==placing it into the other’s mind==, that speaker, he claimed, **made you feel the urgency she felt**, the need **she had to make you really see what she has seen**, that urgency is what **pushed her voice out to you**. it’s the impact or effect you have on your audience. it’s almost like magic.”

• **語調與抑揚頓挫（Prosody）：** 口說語言不僅僅是句子串連成的詞語，我們透過語調和抑揚頓挫來**增強其意義**。
> The spoken word is more than words strung into sentences. We inflect words and thus enhance their meaning. emphasis is perhaps the simplest form of inflection. Prosody is the melody of the voice and also enhances meaning.

• **音高與音量：** 語調（inflection）的主要組成部分是音高（Pitch，聲音的高低）和響度（Loudness/Volume，聲音的強弱）。
> The main components of inflection are pitch and loudness. 
> Loudness is the perceptual correlate of intensity and is a function of sound amplitude: how many molecules are moved by your vocal folds’ vibrations.

> - For the hearing, voice is crucial to effective communication. You must learn the capacity and the limitations of your own voice to assure that you are taking advantage of all your vocal equipment in your efforts to get yourself across to others. As you shall see, you have probably been ill served by your educational experiences to date in your quest to learn how to employ your voice to its full potential and to care for it throughout a lifetime of constant use.
> - Moreover, in our quest to become complete communicators, vocal sounds by no means provide the last word. Among us are the deaf, those who employ sign as their primary mode of communication. From this community we learn the immense importance of visual feedback in interpersonal effectiveness. Facial expression, gesture, posture, position, even what we wear has a significant communication impact. if vocal pitch is critical to meaning, so are face and gesture enormous enhancements to what is transmitted and received. those meanings-beyond-words we call “paraverbals.”

• **可信度（Credibility）：** 成功的溝通需要聽眾準備好接受你傳達的訊息是可靠和值得信任的。可信的演講者需要具備清晰度、準確性、可信性和誠信。亞里士多德（Aristotle）認為，要獲得信任，你需要具備**良好的判斷力（Good sense）、良好的道德品格（Good moral character）和善意（Goodwill）**。
> Aristotle claimed that there are three things that inspire confidence in another’s character: you have good sense, you are a good person, and you have goodwill.