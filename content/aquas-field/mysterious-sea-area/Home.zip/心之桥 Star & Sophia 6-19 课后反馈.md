- 到校时间：18：20

- 上课内容：检查上节课Fannie老师布置的作业。进行Oxford Discovery 第二册的学习。一起学习了unit1的内容。进行单词跟读，意思理解，并且进行了默写。最后简单预习了一下课文。并且完成了练习册两页内容。

- 情况反馈：需要掌握好单词读音，第一单元有些单词读音需要注意，如：
- feather
- scales

注意单词拼写：
amphibians
gills
feather
![IMG_20250619_193941_edit_1735006283251999.jpg](https://supernotes-resources.s3.amazonaws.com/image-uploads/49f422b9-0edf-45f8-9a0f-0508822f773a--IMG_20250619_193941_edit_1735006283251999.jpg)
