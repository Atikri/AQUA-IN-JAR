> Anything's possible
> P104

---
For busy people , chia cops have to be one of the easiest ways to start your day off right. They are packed full of antioxidants , protein and a fibre . Make them the night before to set and grab it the next morning on your way out the door.
:speech_balloon: Why should you soak your chia?
- Chia seeds have many benefits, but something that is especially cool is that chia has the ability to absorb up to 12 times its weight in water. This means that soaked chia slows down digestion and the time it takes for your stomach to empty meeting you will feel fuller for longer.

---
## Ingredients

---
## Steps
1. Have your whisk ready. In a medium mixing bowl, add the almond milk, coconut cream, chia,  maple syrup, vanilla and salt. Begin to whisk straightaway until combined. Leave to sit for 10 minutes. If you don't whisk immediately the chia will clump together.
2. After 10 minutes , briefly whisk again before placing in the fridge to soak for one hour or overnight.

Serve chilled and top with coconut yogurt and fruit of choice such as berries, strawberries, sliced banana and pomegranate seeds.