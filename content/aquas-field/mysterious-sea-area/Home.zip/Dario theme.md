### **一、主题概览与核心理念**

`dario` 主题是一款极简主义的 Hugo 主题，其设计灵感来源于 Dario Amodei 的个人网站。它的核心理念是追求**极度简洁、高性能和优雅的阅读体验**。主题的设计专注于核心的博客功能，因此刻意不包含许多复杂的配置和功能。

从你提供的 `default.css` 文件中可以看到，主题使用了 `Newsreader` 字体和一些自定义的 CSS 变量来实现独特的视觉风格。

### **二、安装与更新**

`dario` 主题提供了三种安装方式，其中 **“Hugo Module”** 是最推荐的，因为它能让你最方便地获取更新。

- **从源代码安装**：最传统的方式，将主题 `.zip` 文件解压到你的 `themes` 文件夹下，并在 `hugo.toml` 或 `hugo.yaml` 中设置 `theme = "dario"`。
  
- **作为 Git 子模块**：如果你使用 Git 管理你的网站，可以添加主题为子模块。
  
- **作为 Hugo Module（推荐）**：这是最现代的方式，使用 `hugo mod init` 和 `hugo mod get` 等指令来管理主题，不需要手动下载或更新。使用这种方式时，请注意**不要再设置 `theme = "dario"`**。
  

### **三、主要配置指南**

主题的配置在 `README.md` 的 **Configuration** 部分有详细说明。你之前遇到的配置没有生效的问题，就是因为你的 `hugo.yaml` 格式不符合主题的要求。

**正确的配置结构**应该是将 `author` 和 `social` 字段放在 `[params]` 下，而不是根目录。

Ini, TOML

```
baseURL = "https://yoursite.com/"
languageCode = "en-us"
title = "log"

theme = "dario" # 如果你是用 Hugo Module 安装，则不需要这行

[params]
  description = "A description of your site"

  [params.author]
    name = "Your Name"
    email = "you@example.com"
    twitter = "@YourXHandle"

```

你之前尝试添加的 Instagram、Facebook 等社交链接，**主题的官方文档中没有提供对应的配置选项**。这再次印证了 `dario` 主题的极简设计，它可能不支持这些社交链接的显示。

### **四、内容与特殊页面**

- **首页介绍文字**：要在首页添加介绍文字，你需要创建 `content/_index.md` 文件。这个文件可以包含 YAML Front Matter（用于设置 `subtitle` 和 `description`）以及 Markdown 内容。
  
- **博客文章**：创建新文章的流程与其他 Hugo 主题类似。文章的 Front Matter 支持 `title`、`author`、`description`、`summary`、`date` 等字段。
  
- **自定义 404 页面**：你可以通过创建 `content/_404.md` 来定制你的 404 错误页面。
  

### **五、提升与建议**

基于你之前遇到的问题，我为你提供以下建议：

1.  **关于代码高亮**：
  
  - **问题所在**：你遇到的代码高亮问题是因为 `dario` 主题**使用了 Highlight.js (hljs)**，而不是 Hugo 内置的 Chroma 高亮系统。两个系统互相冲突导致显示异常。
    
  - **解决方案**：你需要关闭 Hugo 内置的高亮功能。请在你的 `hugo.yaml` 中加入以下配置：
    
    YAML
    
    ```
    markup:
      highlight:
        codeFences: false
    
    ```
    
2.  **关于列表勾选框**：
  
  - **问题所在**：根据你提供的 `default.css` 文件，主题本身没有为 `-[ ]` 这种 Markdown 任务列表提供对应的 CSS 样式。
    
  - **解决方案**：你需要自己为勾选框添加 CSS 样式。在 `assets/css/custom.css` 中添加自定义 CSS。
    
3.  **关于自定义 `index.html`**：
  
  - **问题所在**：你创建的 `layouts/index.html` 是一个纯静态的 HTML 页面，它没有能力去读取和渲染 `_index.md` 里的内容。
    
  - **解决方案**：如果你想自定义首页，同时又能显示 `_index.md` 的内容，你需要在你的 `layouts/index.html` 中加入 Hugo 的模板代码，例如 `{{ .Content }}` 来渲染正文，并使用 `{{ .Params.subtitle }}` 等来获取 Front Matter 中的参数。
    

总而言之，`dario` 主题的设计非常纯粹，它的所有功能都集中在 `README.md` 和 `exampleSite` 中。如果你想增加其未包含的功能（例如社交媒体链接或自定义 Markdown 样式），你需要手动修改主题的模板和 CSS 文件。