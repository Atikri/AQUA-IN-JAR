**1.This doesn't make sense.**
•翻译：这没有道理。
**2.Can you make sense of this?**
•翻译：你能理解这个吗？
**3. It makes sense to save money.**
•翻译：存钱是有意义的。

when things don't quiet seem to make sense