> Anything's possible :page_with_curl: P196
---
## Ingredients:
### Dough
- 1/2 cup yoghurt or coconut yoghurt
- 1 tsp salt
- 3 cups baker's plain flour, plus extra for kneading

### Filling
- 2 cups Swiss chard(100g), stems removed, finely chopped
- 2 tsp olive oil
- 1 cup feta
- 1/2 cup parsley, finely chopped, loosely packed
- 1/4 cup mint leaves
- 2 spring onions, finely chopped including green tops
- 1 tsp garlic, minced
- 1/2 tsp hot paprika
- 1/2 tsp sumac
- 1/2 tsp salt

### To serve
- lemon wedges

---
## Steps:
### Dough
1. Combine yoghurt, 1/2 cup of water and salt in a bowl.
2. Sift flour into the yoghurt mix. Combine together with your hands.
3. Add flour to your kitchen counter. Using your hands, knead the dough. You will know when it's done when it is soft and smooth.
4. Put the dough into a lightly floured bowl and cover with a tea towel. Leave for about 30 minutes.
### Filling
1. Add the Swiss chard and the olive oil to a bowl. Massage with your hands until the Swiss chard slightly softens.
2. Add the rest of the filling ingredients to the Swiss chard. Combine and set aside.
### Bring it all together
1. Lightly flour the kitchen counter. Cut the dough into quarters. Take one quarter of the dough and, using a rolling pin, roll it into a large circle about two to three millimetres thick.
2. Put a quarter of the filling on 1/2 of the circle and fold over the dough. Fold the edges of the dough and seal with a fork.
3. Repeat until the dough is used up.
4. Putting a large pan or barbecue to a medium-high heat. Brush both sides of the gozleme with olive oil. Cook until both sides are golden brown.

Serve with lemon wedges.