I’m going to persist PATH (add D:\npm-global, Git Bash, and Node) and then verify the claude CLI works from new sessions.
```bash
$toAdd=@('D:\npm-global','C:\Program Files\Git\bin','C:\Program Files\nodejs');$old=[Environment]::GetEnvironmentVariable('Path','User');$segs=@();if($old){$segs=$old -split ';' | Where-Object {$_ -ne ''}};foreach($p in $toAdd){if(-not ($segs -contains $p)){$segs=@($p)+$segs}};$new=($segs -join ';');[Environment]::SetEnvironmentVariable('Path',$new,'User');$env:Path=($toAdd -join ';')+';'+$env:Path;cmd /c claude --version
```

### Step-by-step to open and use Claude Code on Windows (installed to D:)

- 1) Open a new terminal
  - PowerShell or CMD (new window so PATH updates apply).

- 2) Verify prerequisites
  - Git Bash: run `bash --version`. If it prints a version, you’re good.
  - Node/npm: run `node -v` and `npm -v` (optional check).

- 3) Go to your project folder on D:
  - PowerShell: `cd D:\your\project\path`
  - CMD: `cd /d D:\your\project\path`

- 4) Launch Claude Code
  - PowerShell (recommended): `cmd /c claude`
    - This uses the `.cmd` shim and avoids PowerShell’s script policy.
  - CMD: `claude`
  - Git Bash: `claude`
  - Direct path (if needed): `D:\npm-global\claude.cmd`

- 5) First-run setup (if prompted)
  - If you’re asked for an API key:
    - PowerShell (current session): `$env:ANTHROPIC_API_KEY='<your_key>'`
    - PowerShell (persist): `[Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY','<your_key>','User')`
    - CMD (persist): `setx ANTHROPIC_API_KEY "<your_key>"`
    - Open a new terminal after setting a persistent variable.

- 6) Quick checks and usage
  - Check version: `claude --version`
  - See help: `claude --help`
  - Start interactive: run `claude` in your project folder and follow the prompts.

Troubleshooting
- “PowerShell blocked script”: Use `cmd /c claude` or run from CMD/Git Bash.
- “git-bash required”: Ensure Git for Windows is installed and `C:\Program Files\Git\bin` is on PATH (we’ve already added it).
- If `claude` isn’t found in a new terminal, confirm `D:\npm-global` is in your user PATH (System Properties → Environment Variables → Path), or run it with the full path `D:\npm-global\claude.cmd`.

Reference: [Claude Code 概述](https://docs.anthropic.com/zh-CN/docs/claude-code/overview)

- I’ve installed everything to D:, added paths, and verified `claude --version` (1.0.86). You can now run `cmd /c claude` in PowerShell, or `claude` in CMD/Git Bash, from any project on D:.