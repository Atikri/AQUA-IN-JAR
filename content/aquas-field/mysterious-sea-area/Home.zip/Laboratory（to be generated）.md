Explore the differences between how people perceive songs recorded in a studio and live music performances. The hypothesis is that live music may provide people with more emotional support.

- 研究睡前唱歌以及早上被歌声唤起对入睡以及晨起的影响