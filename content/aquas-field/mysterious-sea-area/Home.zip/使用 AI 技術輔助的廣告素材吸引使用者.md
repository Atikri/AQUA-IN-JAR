[回應式搜尋廣告](https://my.supernotes.app/?preview=599192af-2235-400a-b78d-9c9b6a5a32b5)會針對使用者的搜尋內容，預測哪些廣告成效最佳，然後將素材資源組成廣告，在使用者查詢當下就完成真正的最佳化，意即在短短一秒內評估數萬個可能放送的廣告，依據比對內容信號和意願信號，向每位使用者顯示更貼近需求的訊息。
> 廣告主從**延展型文字廣告**改用**回應式搜尋廣告**後，在使用相同素材資源和相近單次轉換費用的情況下，轉換次數平均增加了 7%。
> [Google Ads Tutorials: About responsive search ads - YouTube](https://youtu.be/mxdelKnGybM)

# 大規模製作並最佳化回應式搜尋廣告  
  
## 1. 最佳化分數建議
最佳化分數可用來評估 Google Ads 帳戶的預期成效。這個分數以 0 至 100% 表示，100% 代表帳戶能夠全面發揮效益。
![image.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/834896d4-42fd-4840-8bcf-f45595a3d402--image.png)
---
![image.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/6afa1c04-4b7e-40c0-81ac-faf405508ee7--image.png)
最佳化建議會藉由新增圖片素材資源，顯示如何改善回應式搜尋廣告。
---
![image.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/203d22e6-1479-4c88-a9bb-ff36cd3cc801--image.png)
---
# 2. 廣告製作工具 (Search Ads 360) 最佳化建議
有了廣告製作工具，你只要按幾下滑鼠，就能將新的素材資源新增至數千個廣告群組，你可以在**單一畫面中輕鬆更新廣告**，並利用**智慧自動化**為每個廣告群組**自訂廣告**。

# 3. Google Ads 編輯器最佳化建議
Google Ads 編輯器可協助建立並最佳化回應式搜尋廣告，你可以**固定廣告標題**、**檢查廣告優異度**並獲得改進方案。請記得將 Google Ads 編輯器更新至最新版本，才能看到建立回應式搜尋廣告的選項。
![image.png](https://supernotes-resources.s3.amazonaws.com/image-uploads/33111513-426c-4b33-95f0-5fd673833def--image.png)
# 4. 自動建立的素材資源
自動建立的素材資源是一項可自由啟用的廣告活動層級設定，目前正處於測試階段。啟用這項設定，就能產生其他素材資源 (廣告標題和說明)，與你在回應式搜尋廣告中提供的素材資源**搭配使用**。這些新素材資源是根據廣告獨特情境所產生，包括到達網頁、現有廣告和廣告群組中的關鍵字。
有關導入與推出資訊，請參閱[說明中心。](https://support.google.com/google-ads/answer/11259373)

# 廣告優異度
廣告優異度指標會**衡量回應式搜尋廣告**的關聯性、數量和多樣性，並提供可行的意見回饋。
製作回應式搜尋廣告時，廣告優異度指標分為五個不同評等：未完成、不佳、普通、良好與極佳。

# 廣告優異度和素材資源成效有什麼不同？
[廣告優異度](https://my.supernotes.app/?preview=2312a4d3-3bf9-40a4-907a-13b0a763770e)与[素材資源成效](https://my.supernotes.app/?preview=d9ef6c2d-bc27-4466-a71d-e867c1981be4)搭配使用。強大的廣告優異度功能會在製作回應式搜尋廣告時，顯示整體預測品質。廣告放送後，查看素材資源成效標籤，就能**修改個別**素材資源，進一步提升廣告優異度。
---
如要使用廣告關鍵字動態更新廣告文字，請使用[關鍵字插入](https://support.google.com/google-ads/answer/2454041)。