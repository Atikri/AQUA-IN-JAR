# Cauliflower rice sushi

We hold regular cooking workshops where we help people to fall in love with cooking and add a bit of flavour to their recipe repertoire. Cauliflower rice sushi is always a big hit because it is a great way to get the little ones into the kitchen and sneak veggies into the meal at the same time.

---

### ½ medium cauliflower (750g)
1 tsp salt
2 cups [cooked quinoa (p56)](https://my.supernotes.app/?preview=1c8b3038-84e2-438f-8b24-01d39c274ffd)
1 tbsp apple cider vinegar
1 tbsp maple syrup
¼ cup coriander (9g), roughly chopped
sushi wraps (nori wraps)

---

### Fillings (quantity dependent on personal preference)
- avocado
- carrot
- apple
- spring onions
- capsicum

---

### To serve
- [ginger tahini sauce (p82)](https://my.supernotes.app/?preview=14b31dc7-881e-46a0-81db-736dc95ca75f) or tamari

---

### Equipment
- clean cloth or nut milk bag

---

1. In a food processor, 'rice' the cauliflower into rice-sized pieces by pulsing. Make sure you don't over-process the cauliflower, pulsing it in smaller batches to ensure you get an even consistency.

2. Salt the mixture and mix together to make sure it is all covered. Leave for 10 minutes.

3. Using a clean cloth or nut milk bag, squeeze the liquid out of the mixture. Do in small batches at a time. You need to squeeze quite hard. Place the cauliflower in a large bowl, discarding the liquid. You need to do this process otherwise the sushi will fall apart.

4. Add quinoa, apple cider vinegar, maple syrup and coriander to the cauliflower. Combine.

5. Choose your fillings. Slice into thin, long pieces.

6. Spread some of the cauliflower rice mixture over the sushi/nori wrap, add fillings and roll tightly. You don't have to have a bamboo roller. It can make it easier but we prefer to just use our hands.

Serve with [ginger tahini sauce (p82) ](https://my.supernotes.app/?preview=14b31dc7-881e-46a0-81db-736dc95ca75f)or tamari.

---
Anything's possible
172