Made in Kenya  
Cleaning  
For a cleaning aroma try blending with eucalyptus, lavender or lemon.