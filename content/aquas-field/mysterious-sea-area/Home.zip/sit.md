- **Be in two minds** (idiom) - to be unable to decide about something.
- **To chill** (verb) - to relax completely, or not allow things to upset you.
- **Posture** (noun) - the way in which someone usually holds their shoulders, neck, and back, or a particular position in which someone stands, sits, etc.
- **Ergonomic** (adj.) - relating to the design of furniture or equipment which makes it comfortable and effective for people who use it.
- **Cozy** (adj.) - comfortable and pleasant, especially (of a building) because of being small and warm.
- **To curl up** (phrasal verb) - to sit or lie in a position with your arms and legs close to your body.
- **To drift off** (phrasal verb) - to gradually start to sleep.
- **To be short (of/on something)** (phrase) - to not have enough of something.
- **As a matter of course** (idiom) - if something is done as a matter of course, it is a usual part of the way in which things are done and is not special.
- **Seated** (adj.) - sitting.
- **Stiff** (adj.) - firm or hard.
---
*M: Do you always sit down for a long time?*  
  
R: Actually, I try to avoid it when I can. I read a book that said it was really bad for your **posture** and your general health, so I tried to stand wherever possible.  
  ---
*M: Where's your favorite place to sit?*  
  
R: Oh, well, I'm sort of **in two minds** about this, because I love my [](https://successwithielts.com/s11e26#) [couch](https://successwithielts.com/s11e26#), I have a big three seater in my living room, and I love to sit and **chill** there for a bit. But I also have this **ergonomic** chair for my office, and that's pretty comfortable too, so it's great for work.  
  ---
*M: Do you find it easy to fall asleep when sitting on a [](https://successwithielts.com/s11e26#)*  *[sofa](https://successwithielts.com/s11e26#)?*  
  
R: I certainly didn't used to, but I've got to throw for it for Christmas. So it's so **cozy** that sometimes I just **curl up** under it and **drift off**.
---
*M: When you were a child, did you usually sit on the floor?*  
  
R: I think so. Maybe if we were **short on** space, but generally, we usually had enough room to share couches and seats.  
  ---
*M: Do you feel sleepy when you are sitting down?*  
  
R: Well, not as a **matter of course**, but sometimes, if I'm on a bus and they turn up the heating, it's hard to stay conscious. Or maybe if I've been on a flight for several hours, I could drift off in a **seated** position. But I hate that, since I always wake up feeling extremely **stiff** and it's not particularly comfortable.

