Maria: Do you like history?  
>Rory: Yeah, I love it. To the extent I actually studied it at university, and a lot of the books I read for pleasure now are historical accounts. I'm not sure why I like it so much, though. It's just something that clicked with me when I was at school.  
---
Maria: Did you like history when you were young?  
>Rory: Yeah, absolutely. History was one of my favourite classes, and I absolutely excelled at it when we wrote essays on it, regardless of the historical topic. Except for the history of agriculture, I have absolutely no idea why we had to learn about that or at least learn about it in such an off-putting manner. It lacked any energy whatsoever.  
  ---
Maria: When was the last time you read about history?  
>Rory: Well, that would be the last time I picked up the book I'm reading now. It's a kind of almost revisionist history of the world and how Indigenous Americans contributed to Enlightenment thinking and subsequent modes of thought in the West.  
  ---
Maria: Have you ever been to historical museums?  
>Rory: Not recently, but I have been to quite a few, like the McManus Galleries in Dundee, which has a historical art collection, and the Natural History Museum in Oxford. It also has this massive collection of artwork and cultural artefacts that were produced by Native people from across the world. They're of great interest to me on a personal and professional level, since I like learning about them, but I also have to teach students about culture at times.