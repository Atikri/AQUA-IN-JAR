**Maria: Rory, is your home clean?**  
Rory: Isn't everyone's? Yeah, I do some dusting and clean the dishes fairly regularly. Though for bigger cleaning jobs, I usually hire a cleaner to get the place in good condition before I have company around or something like that.  
  
**Maria: Do you like housework?**  
Rory: I like it when it's done. I'm not a great fan of the actual process of it. It eats into time I could be spending on something else, like reading or just relaxing.  
  
**Maria: What housework do you dislike?**  
Rory: I'm not a huge fan of cleaning the kitchen or the bathroom, really. The moment you're done, people are using those rooms and making them messy again. So it seems rather pointless. Of course, a home isn't always in a perfect state of homeostasis, so that's not true. But it definitely feels like a waste of time, at least from time to time.  
  
**Maria: How often do you do housework?**  
Rory: It depends on the job we're talking about, I suppose. If it's a whole house clean, then that happens every few months or so. But I do things like sweep the floors every week, and doing the dishes is a daily task.  
  
**Maria: Will you do more housework in the future?**  
Rory: Oh God, I hope not. I'm not a big fan of it now and I hardly do anything. Could you imagine what I'd be like if I had more to do? Ideally, I'll have a few robots or machines to take care of all but the most finicky tasks, which they can't do. And that will be it.